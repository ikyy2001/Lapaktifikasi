import React, { useState } from 'react';
import { FileSpreadsheet, Clock, CheckCircle2, Upload, Send, Play, Trophy, FileText, ArrowRight } from 'lucide-react';
import { MOCK_ASSIGNMENTS } from '../data/mockData';
import { Assignment } from '../types';
import { getStatusBadgeClass, getStatusLabel } from '../utils/formatters';

export const TugasUjianSection: React.FC = () => {
  const [assignments, setAssignments] = useState<Assignment[]>(MOCK_ASSIGNMENTS);
  const [selectedAssignment, setSelectedAssignment] = useState<Assignment | null>(null);
  const [uploadedFile, setUploadedFile] = useState<string | null>(null);

  // CBT Exam Simulation State
  const [isCbtActive, setIsCbtActive] = useState(false);
  const [currentQuestionIdx, setCurrentQuestionIdx] = useState(0);
  const [userAnswers, setUserAnswers] = useState<Record<number, string>>({});
  const [cbtFinished, setCbtFinished] = useState(false);

  const cbtQuestions = [
    {
      id: 1,
      text: 'Berapakah hasil turunan pertama dari f(x) = 3x^3 - 4x^2 + 7x - 12 terhadap x?',
      options: ['A. 9x^2 - 8x + 7', 'B. 6x^2 - 4x + 7', 'C. 9x^2 - 4x + 12', 'D. 3x^2 - 8x + 1'],
      correct: 'A. 9x^2 - 8x + 7',
    },
    {
      id: 2,
      text: 'Jika f(x) = sin(2x), maka nilai f\'(π/4) adalah...',
      options: ['A. 1', 'B. 0', 'C. -1', 'D. 2'],
      correct: 'B. 0',
    },
    {
      id: 3,
      text: 'Panjang vektor a = 3i - 4j + 12k adalah...',
      options: ['A. 11', 'B. 12', 'C. 13', 'D. 15'],
      correct: 'C. 13',
    },
    {
      id: 4,
      text: 'Hasil integral dari ∫ (6x^2 + 2x) dx adalah...',
      options: ['A. 2x^3 + x^2 + C', 'B. 3x^3 + 2x^2 + C', 'C. 6x^3 + x^2 + C', 'D. 2x^3 + 2x^2 + C'],
      correct: 'A. 2x^3 + x^2 + C',
    },
    {
      id: 5,
      text: 'Nilai limit x → 0 dari (sin 4x) / (2x) adalah...',
      options: ['A. 1', 'B. 2', 'C. 4', 'D. 0.5'],
      correct: 'B. 2',
    }
  ];

  const handleSelectOption = (option: string) => {
    setUserAnswers({ ...userAnswers, [currentQuestionIdx]: option });
  };

  const handleFinishCbt = () => {
    setCbtFinished(true);
  };

  const calculateCbtScore = () => {
    let score = 0;
    cbtQuestions.forEach((q, idx) => {
      if (userAnswers[idx] === q.correct) {
        score += 20; // 5 questions = 100 max score
      }
    });
    return score;
  };

  const handleSubmitAssignment = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedAssignment) return;

    const updated = assignments.map(a => {
      if (a.id === selectedAssignment.id) {
        return {
          ...a,
          status: 'sudah_dikirim' as const,
          attachmentUrl: uploadedFile || 'Jawaban_Dimas_KABIN.pdf'
        };
      }
      return a;
    });

    setAssignments(updated);
    setSelectedAssignment(null);
    setUploadedFile(null);
  };

  return (
    <div className="space-y-6">
      
      {/* Top Banner */}
      <div className="bg-white p-6 rounded-2xl border border-slate-200/80 shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-extrabold text-slate-900 flex items-center gap-2">
            <FileSpreadsheet className="w-6 h-6 text-indigo-600" />
            Tugas Akademik & Simulasi Ujian CBT
          </h2>
          <p className="text-xs text-slate-500 mt-1">
            Kirim berkas tugas sekolah atau ikuti simulasi Penilaian Tengah Semester CBT
          </p>
        </div>

        <button
          onClick={() => {
            setIsCbtActive(true);
            setCbtFinished(false);
            setCurrentQuestionIdx(0);
            setUserAnswers({});
          }}
          className="px-4 py-2 bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-600 hover:to-amber-700 text-slate-950 rounded-xl text-xs font-bold flex items-center gap-2 shadow-md transition-all self-start md:self-auto"
        >
          <Play className="w-4 h-4 fill-slate-950" />
          <span>Mulai Simulasi CBT Matematika</span>
        </button>
      </div>

      {/* CBT Active Modal Simulation */}
      {isCbtActive && (
        <div className="fixed inset-0 bg-slate-950/80 backdrop-blur-md z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl max-w-2xl w-full p-6 sm:p-8 space-y-6 shadow-2xl animate-in zoom-in-95">
            
            {!cbtFinished ? (
              <>
                <div className="flex items-center justify-between border-b border-slate-100 pb-4">
                  <div>
                    <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-amber-100 text-amber-800 uppercase">
                      KABIN CBT EXAM SIMULATOR
                    </span>
                    <h3 className="font-extrabold text-slate-900 text-base sm:text-lg mt-1">
                      Kuis Latihan: Matematika Peminatan
                    </h3>
                  </div>

                  <div className="flex items-center gap-2 bg-slate-900 text-white text-xs font-mono font-bold px-3 py-1.5 rounded-xl">
                    <Clock className="w-4 h-4 text-amber-400" />
                    <span>08:45 WIB</span>
                  </div>
                </div>

                {/* Question Navigation Pills */}
                <div className="flex items-center gap-2 overflow-x-auto pb-1">
                  {cbtQuestions.map((q, idx) => (
                    <button
                      key={q.id}
                      onClick={() => setCurrentQuestionIdx(idx)}
                      className={`
                        w-9 h-9 rounded-xl text-xs font-bold transition-all shrink-0
                        ${currentQuestionIdx === idx 
                          ? 'bg-indigo-600 text-white shadow-md' 
                          : userAnswers[idx] 
                            ? 'bg-emerald-100 text-emerald-800 border border-emerald-300' 
                            : 'bg-slate-100 text-slate-600'}
                      `}
                    >
                      {idx + 1}
                    </button>
                  ))}
                </div>

                {/* Active Question Box */}
                <div className="p-5 rounded-2xl bg-slate-50 border border-slate-200/80 space-y-4">
                  <h4 className="text-sm sm:text-base font-bold text-slate-900 leading-relaxed">
                    Soal No. {currentQuestionIdx + 1}: {cbtQuestions[currentQuestionIdx].text}
                  </h4>

                  <div className="space-y-2 pt-2">
                    {cbtQuestions[currentQuestionIdx].options.map((opt, optIdx) => (
                      <button
                        key={optIdx}
                        onClick={() => handleSelectOption(opt)}
                        className={`
                          w-full p-3.5 rounded-xl text-left text-xs font-semibold transition-all border
                          ${userAnswers[currentQuestionIdx] === opt
                            ? 'bg-indigo-600 text-white border-indigo-600 shadow-sm'
                            : 'bg-white text-slate-800 border-slate-200 hover:bg-indigo-50'}
                        `}
                      >
                        {opt}
                      </button>
                    ))}
                  </div>
                </div>

                {/* Bottom Navigation */}
                <div className="flex items-center justify-between pt-2">
                  <button
                    disabled={currentQuestionIdx === 0}
                    onClick={() => setCurrentQuestionIdx(currentQuestionIdx - 1)}
                    className="px-4 py-2 rounded-xl bg-slate-100 text-slate-700 text-xs font-bold disabled:opacity-40"
                  >
                    Sebelumnya
                  </button>

                  {currentQuestionIdx < cbtQuestions.length - 1 ? (
                    <button
                      onClick={() => setCurrentQuestionIdx(currentQuestionIdx + 1)}
                      className="px-5 py-2 rounded-xl bg-indigo-600 text-white text-xs font-bold hover:bg-indigo-700"
                    >
                      Selanjutnya
                    </button>
                  ) : (
                    <button
                      onClick={handleFinishCbt}
                      className="px-6 py-2 rounded-xl bg-emerald-600 text-white text-xs font-extrabold hover:bg-emerald-700 shadow-md"
                    >
                      Selesai & Kumpulkan
                    </button>
                  )}
                </div>
              </>
            ) : (
              /* CBT Results Screen */
              <div className="text-center space-y-5 py-4">
                <div className="w-16 h-16 bg-emerald-100 text-emerald-600 rounded-full flex items-center justify-center mx-auto shadow-md">
                  <Trophy className="w-8 h-8" />
                </div>

                <div>
                  <span className="text-xs font-bold text-emerald-700 uppercase tracking-wider">
                    Hasil Ujian CBT Selesai
                  </span>
                  <h3 className="text-3xl font-extrabold text-slate-900 mt-1">
                    Skor Nilai: {calculateCbtScore()} / 100
                  </h3>
                  <p className="text-xs text-slate-500 mt-1">
                    {calculateCbtScore() >= 80 ? 'Selamat! Capaian pembelajaran Anda Sangat Baik.' : 'Bagus! Tetap tingkatkan latihan soal.'}
                  </p>
                </div>

                <div className="p-4 bg-slate-50 rounded-2xl border border-slate-200/80 text-left space-y-2">
                  <h4 className="text-xs font-bold text-slate-800">Kunci Jawaban Singkat:</h4>
                  {cbtQuestions.map((q, idx) => (
                    <div key={q.id} className="text-[11px] flex items-center justify-between py-1 border-b border-slate-100 last:border-0">
                      <span>Soal {idx + 1}: Kunci <strong className="text-emerald-700">{q.correct}</strong></span>
                      <span className={userAnswers[idx] === q.correct ? 'text-emerald-600 font-bold' : 'text-rose-600 font-bold'}>
                        {userAnswers[idx] === q.correct ? '✓ Benar' : '✕ Salah'}
                      </span>
                    </div>
                  ))}
                </div>

                <button
                  onClick={() => setIsCbtActive(false)}
                  className="w-full py-2.5 rounded-xl bg-slate-900 text-white text-xs font-bold hover:bg-slate-800"
                >
                  Tutup Hasil CBT
                </button>
              </div>
            )}

          </div>
        </div>
      )}

      {/* Assignment List */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {assignments.map((asg) => (
          <div 
            key={asg.id}
            className="bg-white p-5 rounded-2xl border border-slate-200/80 shadow-xs flex flex-col justify-between space-y-4"
          >
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-[10px] font-bold px-2.5 py-0.5 rounded-md bg-indigo-50 text-indigo-700">
                  {asg.subject}
                </span>
                <span className={`text-[10px] font-bold px-2.5 py-0.5 rounded-full border ${getStatusBadgeClass(asg.status)}`}>
                  {getStatusLabel(asg.status)}
                </span>
              </div>

              <h3 className="text-sm font-bold text-slate-900 leading-snug">{asg.title}</h3>
              <p className="text-xs text-slate-500 leading-relaxed">{asg.description}</p>
            </div>

            <div className="pt-3 border-t border-slate-100 flex items-center justify-between text-xs">
              <span className="text-slate-500 text-[11px]">
                Deadline: <strong className="text-slate-800">{asg.deadline}</strong>
              </span>

              {asg.status === 'belum_dikirim' ? (
                <button
                  onClick={() => setSelectedAssignment(asg)}
                  className="px-3.5 py-1.5 bg-indigo-600 hover:bg-indigo-700 text-white font-bold rounded-lg text-xs"
                >
                  Kirim Jawaban
                </button>
              ) : asg.score ? (
                <span className="font-extrabold text-emerald-600 text-sm">
                  Nilai: {asg.score}/100
                </span>
              ) : (
                <span className="text-[11px] font-semibold text-amber-600">
                  Terimakasih, Terkirim
                </span>
              )}
            </div>
          </div>
        ))}
      </div>

      {/* Submit Assignment File Modal */}
      {selectedAssignment && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs z-50 flex items-center justify-center p-4">
          <form onSubmit={handleSubmitAssignment} className="bg-white rounded-3xl max-w-md w-full p-6 space-y-4 shadow-2xl">
            <h3 className="font-bold text-slate-900 text-base border-b border-slate-100 pb-2">
              Kirim Jawaban: {selectedAssignment.subject}
            </h3>

            <p className="text-xs text-slate-600 leading-relaxed">
              {selectedAssignment.title}
            </p>

            <div 
              onClick={() => setUploadedFile(`Jawaban_Dimas_${selectedAssignment.subject.replace(/\s/g, '_')}.pdf`)}
              className="p-6 border-2 border-dashed border-indigo-200 bg-indigo-50/50 hover:bg-indigo-50 rounded-2xl text-center cursor-pointer transition-colors"
            >
              <Upload className="w-8 h-8 text-indigo-600 mx-auto mb-2" />
              <span className="text-xs font-bold text-indigo-900 block">
                {uploadedFile ? uploadedFile : 'Klik untuk Unggah Berkas PDF Jawaban'}
              </span>
              <span className="text-[10px] text-slate-400 mt-1 block">Format PDF / DOCX • Maksimal 10 MB</span>
            </div>

            <div className="flex gap-2 pt-2">
              <button
                type="button"
                onClick={() => setSelectedAssignment(null)}
                className="w-1/2 py-2.5 rounded-xl bg-slate-100 text-slate-700 text-xs font-bold"
              >
                Batal
              </button>
              <button
                type="submit"
                className="w-1/2 py-2.5 rounded-xl bg-indigo-600 text-white text-xs font-bold hover:bg-indigo-700"
              >
                Kirim Tugas
              </button>
            </div>
          </form>
        </div>
      )}

    </div>
  );
};
