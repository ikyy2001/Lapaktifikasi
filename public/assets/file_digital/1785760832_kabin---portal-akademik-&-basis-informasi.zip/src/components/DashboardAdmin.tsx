import React from 'react';
import { 
  Building2, 
  Users, 
  GraduationCap, 
  Database, 
  Server, 
  ShieldAlert, 
  Megaphone,
  CheckCircle2,
  RefreshCw
} from 'lucide-react';
import { UserProfile } from '../types';
import { SCHOOL_INFO } from '../data/mockData';

interface DashboardAdminProps {
  profile: UserProfile;
  onNavigate: (tab: string) => void;
}

export const DashboardAdmin: React.FC<DashboardAdminProps> = ({
  profile,
  onNavigate,
}) => {
  return (
    <div className="space-y-6">
      
      {/* Admin Top Banner */}
      <div className="relative overflow-hidden rounded-3xl bg-gradient-to-r from-slate-900 via-indigo-950 to-slate-900 text-white p-6 sm:p-8 shadow-xl shadow-slate-950/20">
        <div className="relative z-10 flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
          <div className="space-y-2 max-w-xl">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-white/10 backdrop-blur-md border border-white/10 text-xs font-semibold text-indigo-200">
              <Server className="w-3.5 h-3.5 text-emerald-400" />
              <span>Pusat Kendali Administrasi KABIN</span>
            </div>
            <h2 className="text-2xl sm:text-3xl font-extrabold tracking-tight">
              KABIN Administrator Dashboard
            </h2>
            <p className="text-slate-300 text-sm leading-relaxed">
              {SCHOOL_INFO.name} ({SCHOOL_INFO.code}) • Pengelola Tata Usaha & Infrastruktur Digital
            </p>
          </div>

          <div className="flex items-center gap-3">
            <button
              onClick={() => onNavigate('pengumuman')}
              className="px-4 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-sm shadow-lg flex items-center gap-2 transition-all"
            >
              <Megaphone className="w-4 h-4" />
              <span>Buat Pengumuman Sekolah</span>
            </button>
          </div>
        </div>
      </div>

      {/* Admin System Metrics */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        
        <div className="bg-white p-5 rounded-2xl border border-slate-200/80 shadow-xs">
          <div className="flex items-center justify-between">
            <span className="text-xs font-medium text-slate-500 uppercase tracking-wider">Total Siswa Aktif</span>
            <div className="w-9 h-9 rounded-xl bg-indigo-50 text-indigo-600 flex items-center justify-center">
              <Users className="w-5 h-5" />
            </div>
          </div>
          <div className="mt-3 flex items-baseline gap-2">
            <span className="text-3xl font-extrabold text-slate-900">1,080</span>
            <span className="text-xs font-bold text-emerald-600 bg-emerald-50 px-2 py-0.5 rounded-full">
              30 Rombel
            </span>
          </div>
          <p className="text-xs text-slate-500 mt-1">Siswa Terverifikasi NISN</p>
        </div>

        <div className="bg-white p-5 rounded-2xl border border-slate-200/80 shadow-xs">
          <div className="flex items-center justify-between">
            <span className="text-xs font-medium text-slate-500 uppercase tracking-wider">Total Guru & Tendik</span>
            <div className="w-9 h-9 rounded-xl bg-emerald-50 text-emerald-600 flex items-center justify-center">
              <GraduationCap className="w-5 h-5" />
            </div>
          </div>
          <div className="mt-3 flex items-baseline gap-2">
            <span className="text-3xl font-extrabold text-slate-900">72</span>
            <span className="text-xs font-bold text-emerald-600 bg-emerald-50 px-2 py-0.5 rounded-full">
              PNS & GTT
            </span>
          </div>
          <p className="text-xs text-slate-500 mt-1">100% Menggunakan KABIN</p>
        </div>

        <div className="bg-white p-5 rounded-2xl border border-slate-200/80 shadow-xs">
          <div className="flex items-center justify-between">
            <span className="text-xs font-medium text-slate-500 uppercase tracking-wider">Server Status KABIN</span>
            <div className="w-9 h-9 rounded-xl bg-emerald-50 text-emerald-600 flex items-center justify-center">
              <Server className="w-5 h-5" />
            </div>
          </div>
          <div className="mt-3 flex items-baseline gap-2">
            <span className="text-3xl font-extrabold text-slate-900">99.9%</span>
            <span className="text-xs font-bold text-emerald-600 bg-emerald-50 px-2 py-0.5 rounded-full">
              Optimal
            </span>
          </div>
          <p className="text-xs text-slate-500 mt-1">Latency: 18ms • Cloud Run</p>
        </div>

        <div className="bg-white p-5 rounded-2xl border border-slate-200/80 shadow-xs">
          <div className="flex items-center justify-between">
            <span className="text-xs font-medium text-slate-500 uppercase tracking-wider">Pembayaran SPP Masuk</span>
            <div className="w-9 h-9 rounded-xl bg-blue-50 text-blue-600 flex items-center justify-center">
              <Database className="w-5 h-5" />
            </div>
          </div>
          <div className="mt-3 flex items-baseline gap-2">
            <span className="text-3xl font-extrabold text-slate-900">92%</span>
            <span className="text-xs font-bold text-blue-600 bg-blue-50 px-2 py-0.5 rounded-full">
              Agustus
            </span>
          </div>
          <p className="text-xs text-slate-500 mt-1">993 Siswa Lunas</p>
        </div>

      </div>

      {/* System Health & Activity Logs */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        
        <div className="bg-white rounded-2xl border border-slate-200/80 p-6 shadow-xs space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-base font-bold text-slate-900">Log Aktivitas Sistem Terbaru</h3>
            <span className="text-xs text-slate-400">Realtime Update</span>
          </div>

          <div className="space-y-3">
            {[
              { time: '10:14:02', action: 'Input Nilai Tugas Fisika', user: 'Bpk. Drs. Haryono, M.Si', type: 'info' },
              { time: '09:45:11', action: 'Presensi QR Fingerprint Masuk (1,012 Siswa)', user: 'Mesin Mesin Auto-Sync', type: 'success' },
              { time: '08:30:00', action: 'Pembayaran SPP Virtual Account Mandiri', user: 'Wali Siswa (Bambang W.)', type: 'success' },
              { time: '07:00:15', action: 'Pengumuman PTS Genap Diterbitkan', user: 'Tim Kurikulum', type: 'info' },
            ].map((log, i) => (
              <div key={i} className="p-3 rounded-xl bg-slate-50 border border-slate-200/60 flex items-center justify-between text-xs">
                <div>
                  <span className="font-bold text-slate-800">{log.action}</span>
                  <p className="text-slate-500 mt-0.5">{log.user}</p>
                </div>
                <span className="text-[10px] font-semibold text-slate-400 bg-white px-2 py-1 rounded-md border border-slate-200">
                  {log.time}
                </span>
              </div>
            ))}
          </div>
        </div>

        <div className="bg-white rounded-2xl border border-slate-200/80 p-6 shadow-xs space-y-4">
          <h3 className="text-base font-bold text-slate-900">Pemeliharaan & Cadangan Data</h3>
          
          <div className="p-4 rounded-xl bg-indigo-50/60 border border-indigo-100 space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-indigo-900">Backup Otomatis Database KABIN</span>
              <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-800">
                Berhasil (03:00 WIB)
              </span>
            </div>
            <p className="text-xs text-slate-600">
              Database PostgreSQL KABIN dicadangkan setiap hari pada pukul 03.00 WIB secara terenkripsi.
            </p>
            <button className="px-3.5 py-1.5 rounded-lg bg-indigo-600 text-white text-xs font-semibold hover:bg-indigo-700 flex items-center gap-2">
              <RefreshCw className="w-3.5 h-3.5" />
              <span>Jalankan Manual Backup Sekarang</span>
            </button>
          </div>
        </div>

      </div>

    </div>
  );
};
