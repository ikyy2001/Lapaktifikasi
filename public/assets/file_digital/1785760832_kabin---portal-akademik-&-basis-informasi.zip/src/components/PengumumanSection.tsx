import React, { useState } from 'react';
import { Megaphone, Pin, Eye, Calendar, User, Search, BookOpen, PlusCircle } from 'lucide-react';
import { MOCK_ANNOUNCEMENTS } from '../data/mockData';
import { Announcement, UserRole } from '../types';

interface PengumumanSectionProps {
  userRole: UserRole;
}

export const PengumumanSection: React.FC<PengumumanSectionProps> = ({ userRole }) => {
  const [selectedCategory, setSelectedCategory] = useState<string>('Semua');
  const [activeAnnouncement, setActiveAnnouncement] = useState<Announcement | null>(null);
  const [announcementsList, setAnnouncementsList] = useState<Announcement[]>(MOCK_ANNOUNCEMENTS);
  const [showCreateModal, setShowCreateModal] = useState(false);

  // New announcement form state
  const [newTitle, setNewTitle] = useState('');
  const [newContent, setNewContent] = useState('');
  const [newCategory, setNewCategory] = useState<'Akademik' | 'Kegiatan' | 'Keuangan'>('Akademik');

  const categories = ['Semua', 'Akademik', 'Kegiatan', 'Keuangan'];

  const filteredAnnouncements = announcementsList.filter(a => {
    if (selectedCategory === 'Semua') return true;
    return a.category === selectedCategory;
  });

  const handleCreateAnnouncement = (e: React.FormEvent) => {
    e.preventDefault();
    const newAnc: Announcement = {
      id: `anc-${Date.now()}`,
      title: newTitle,
      category: newCategory,
      date: '02 Agustus 2026',
      author: 'Administrator KABIN',
      authorRole: 'Tata Usaha / IT',
      authorAvatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=100&auto=format&fit=crop&q=80',
      summary: newContent.slice(0, 100) + '...',
      content: newContent,
      readCount: 1,
    };
    setAnnouncementsList([newAnc, ...announcementsList]);
    setShowCreateModal(false);
    setNewTitle('');
    setNewContent('');
  };

  return (
    <div className="space-y-6">
      
      {/* Top Banner */}
      <div className="bg-white p-6 rounded-2xl border border-slate-200/80 shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-extrabold text-slate-900 flex items-center gap-2">
            <Megaphone className="w-6 h-6 text-indigo-600" />
            Pengumuman & Berita Sekolah
          </h2>
          <p className="text-xs text-slate-500 mt-1">
            Informasi resmi terkini dari Kepala Sekolah, Kurikulum, dan Kesiswaan SMAN 1 Nusantara
          </p>
        </div>

        {(userRole === 'admin' || userRole === 'guru') && (
          <button
            onClick={() => setShowCreateModal(true)}
            className="px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-xs font-bold flex items-center gap-2 transition-colors self-start md:self-auto"
          >
            <PlusCircle className="w-4 h-4" />
            <span>Buat Pengumuman Baru</span>
          </button>
        )}
      </div>

      {/* Category Pills */}
      <div className="flex items-center gap-2 overflow-x-auto pb-1">
        {categories.map((cat) => (
          <button
            key={cat}
            onClick={() => setSelectedCategory(cat)}
            className={`
              px-5 py-2 rounded-xl text-xs font-bold transition-all shrink-0
              ${selectedCategory === cat 
                ? 'bg-indigo-600 text-white shadow-md shadow-indigo-200' 
                : 'bg-white text-slate-600 hover:bg-slate-100 border border-slate-200/80'}
            `}
          >
            {cat}
          </button>
        ))}
      </div>

      {/* Announcement Cards Feed */}
      <div className="space-y-4">
        {filteredAnnouncements.map((anc) => (
          <div
            key={anc.id}
            className={`
              bg-white p-6 rounded-2xl border transition-all duration-200 shadow-xs hover:border-indigo-200
              ${anc.pinned ? 'border-indigo-300 ring-2 ring-indigo-500/10' : 'border-slate-200/80'}
            `}
          >
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
              <div className="space-y-2 flex-1">
                <div className="flex items-center gap-2">
                  {anc.pinned && (
                    <span className="inline-flex items-center gap-1 text-[10px] font-bold px-2.5 py-0.5 rounded-full bg-indigo-600 text-white">
                      <Pin className="w-3 h-3 fill-white" />
                      Disematkan
                    </span>
                  )}
                  <span className="text-[10px] font-bold px-2.5 py-0.5 rounded-full bg-slate-100 text-slate-700 uppercase">
                    {anc.category}
                  </span>
                  <span className="text-xs text-slate-400">• {anc.date}</span>
                </div>

                <h3 className="text-base font-extrabold text-slate-900 leading-snug">
                  {anc.title}
                </h3>

                <p className="text-xs text-slate-600 leading-relaxed line-clamp-2">
                  {anc.summary}
                </p>

                <div className="flex items-center gap-4 text-xs text-slate-500 pt-2">
                  <div className="flex items-center gap-2">
                    <img src={anc.authorAvatar} alt={anc.author} className="w-5 h-5 rounded-full object-cover" />
                    <span className="font-semibold text-slate-700">{anc.author}</span>
                  </div>
                  <span className="flex items-center gap-1">
                    <Eye className="w-3.5 h-3.5" />
                    {anc.readCount} Dibaca
                  </span>
                </div>
              </div>

              <button
                onClick={() => setActiveAnnouncement(anc)}
                className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-800 rounded-xl text-xs font-bold shrink-0 self-start md:self-center"
              >
                Baca Lengkap
              </button>
            </div>
          </div>
        ))}
      </div>

      {/* Read Detail Modal */}
      {activeAnnouncement && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl max-w-xl w-full p-6 sm:p-8 space-y-4 shadow-2xl max-h-[85vh] overflow-y-auto">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3">
              <span className="text-[11px] font-bold px-2.5 py-0.5 rounded-full bg-indigo-100 text-indigo-800">
                {activeAnnouncement.category}
              </span>
              <button 
                onClick={() => setActiveAnnouncement(null)}
                className="text-slate-400 hover:text-slate-600 font-bold text-sm"
              >
                ✕
              </button>
            </div>

            <h3 className="text-xl font-extrabold text-slate-900 leading-snug">
              {activeAnnouncement.title}
            </h3>

            <div className="flex items-center gap-3 text-xs text-slate-500 border-b border-slate-100 pb-3">
              <img src={activeAnnouncement.authorAvatar} alt="" className="w-6 h-6 rounded-full" />
              <span>{activeAnnouncement.author} ({activeAnnouncement.authorRole})</span>
              <span>•</span>
              <span>{activeAnnouncement.date}</span>
            </div>

            {activeAnnouncement.image && (
              <img src={activeAnnouncement.image} alt="" className="w-full h-48 object-cover rounded-2xl" />
            )}

            <p className="text-xs text-slate-700 leading-relaxed whitespace-pre-line">
              {activeAnnouncement.content}
            </p>

            <button
              onClick={() => setActiveAnnouncement(null)}
              className="w-full py-2.5 rounded-xl bg-slate-900 text-white font-bold text-xs"
            >
              Tutup Pengumuman
            </button>
          </div>
        </div>
      )}

      {/* Create Announcement Modal */}
      {showCreateModal && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs z-50 flex items-center justify-center p-4">
          <form onSubmit={handleCreateAnnouncement} className="bg-white rounded-3xl max-w-md w-full p-6 space-y-4 shadow-2xl">
            <h3 className="font-bold text-slate-900 text-base border-b border-slate-100 pb-2">
              Buat Pengumuman Sekolah Baru
            </h3>

            <div>
              <label className="text-xs font-bold text-slate-700">Kategori</label>
              <select
                value={newCategory}
                onChange={(e) => setNewCategory(e.target.value as any)}
                className="w-full mt-1 p-2.5 bg-slate-100 text-xs rounded-xl border border-slate-200"
              >
                <option value="Akademik">Akademik</option>
                <option value="Kegiatan">Kegiatan</option>
                <option value="Keuangan">Keuangan</option>
              </select>
            </div>

            <div>
              <label className="text-xs font-bold text-slate-700">Judul Pengumuman</label>
              <input
                type="text"
                value={newTitle}
                onChange={(e) => setNewTitle(e.target.value)}
                placeholder="Judul resmi pengumuman..."
                className="w-full mt-1 p-2.5 bg-slate-100 text-xs rounded-xl border border-slate-200"
                required
              />
            </div>

            <div>
              <label className="text-xs font-bold text-slate-700">Isi Pengumuman Lengkap</label>
              <textarea
                value={newContent}
                onChange={(e) => setNewContent(e.target.value)}
                placeholder="Tuliskan detail pengumuman sekolah..."
                className="w-full mt-1 p-2.5 bg-slate-100 text-xs rounded-xl border border-slate-200 h-28"
                required
              />
            </div>

            <div className="flex gap-2 pt-2">
              <button
                type="button"
                onClick={() => setShowCreateModal(false)}
                className="w-1/2 py-2.5 rounded-xl bg-slate-100 text-slate-700 text-xs font-bold"
              >
                Batal
              </button>
              <button
                type="submit"
                className="w-1/2 py-2.5 rounded-xl bg-indigo-600 text-white text-xs font-bold hover:bg-indigo-700"
              >
                Terbitkan Pengumuman
              </button>
            </div>
          </form>
        </div>
      )}

    </div>
  );
};
