import React from 'react';
import { 
  LayoutDashboard, 
  CalendarDays, 
  GraduationCap, 
  UserCheck, 
  FileSpreadsheet, 
  Megaphone, 
  CreditCard, 
  Sparkles,
  School,
  X
} from 'lucide-react';
import { UserRole } from '../types';

interface SidebarProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
  currentRole: UserRole;
  isMobileOpen: boolean;
  setIsMobileOpen: (open: boolean) => void;
}

export const Sidebar: React.FC<SidebarProps> = ({
  activeTab,
  setActiveTab,
  currentRole,
  isMobileOpen,
  setIsMobileOpen,
}) => {
  const menuItems = [
    { id: 'dashboard', label: 'Beranda Utama', icon: LayoutDashboard },
    { id: 'jadwal', label: 'Jadwal & Kalender', icon: CalendarDays },
    { id: 'nilai', label: 'Nilai & Rapor', icon: GraduationCap },
    { id: 'presensi', label: 'Presensi & Kehadiran', icon: UserCheck },
    { id: 'tugas', label: 'Tugas & CBT Ujian', icon: FileSpreadsheet },
    { id: 'pengumuman', label: 'Pengumuman Sekolah', icon: Megaphone },
    { id: 'keuangan', label: 'Keuangan SPP', icon: CreditCard, roleOnly: ['siswa', 'orang_tua', 'admin'] },
    { id: 'ai-asisten', label: 'KABIN AI Asisten', icon: Sparkles, badge: 'AI' },
  ];

  const filteredMenuItems = menuItems.filter(item => {
    if (!item.roleOnly) return true;
    return item.roleOnly.includes(currentRole);
  });

  return (
    <>
      {/* Mobile backdrop */}
      {isMobileOpen && (
        <div 
          className="fixed inset-0 bg-slate-900/50 backdrop-blur-xs z-40 lg:hidden"
          onClick={() => setIsMobileOpen(false)}
        />
      )}

      {/* Sidebar container */}
      <aside className={`
        fixed lg:static inset-y-0 left-0 z-50
        w-72 bg-white border-r border-slate-200/80 flex flex-col justify-between
        transform transition-transform duration-300 ease-in-out
        ${isMobileOpen ? 'translate-x-0' : '-translate-x-full lg:translate-x-0'}
      `}>
        {/* Top Header Logo */}
        <div>
          <div className="p-6 border-b border-slate-100 flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-indigo-600 via-indigo-700 to-blue-600 flex items-center justify-center text-white shadow-md shadow-indigo-200">
                <School className="w-6 h-6" />
              </div>
              <div>
                <h1 className="font-extrabold text-xl tracking-tight text-slate-900 leading-none">
                  KABIN
                </h1>
                <p className="text-[11px] font-medium text-slate-500 mt-0.5">
                  Kawasan Akademik & Basis Informasi
                </p>
              </div>
            </div>
            
            <button 
              onClick={() => setIsMobileOpen(false)}
              className="lg:hidden p-1.5 rounded-lg text-slate-400 hover:text-slate-600 hover:bg-slate-100"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Navigation Items */}
          <nav className="p-4 space-y-1.5">
            <div className="px-3 py-2 text-[11px] font-semibold tracking-wider text-slate-400 uppercase">
              Menu Ekosistem
            </div>

            {filteredMenuItems.map((item) => {
              const Icon = item.icon;
              const isActive = activeTab === item.id;
              
              return (
                <button
                  key={item.id}
                  onClick={() => {
                    setActiveTab(item.id);
                    setIsMobileOpen(false);
                  }}
                  className={`
                    w-full flex items-center justify-between px-3.5 py-2.5 rounded-xl text-sm font-medium transition-all duration-200
                    ${isActive 
                      ? 'bg-indigo-600 text-white shadow-sm shadow-indigo-200 font-semibold' 
                      : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100/80'}
                  `}
                >
                  <div className="flex items-center gap-3">
                    <Icon className={`w-5 h-5 ${isActive ? 'text-white' : 'text-slate-500'}`} />
                    <span>{item.label}</span>
                  </div>

                  {item.badge && (
                    <span className={`
                      text-[10px] font-bold px-2 py-0.5 rounded-full uppercase tracking-wider
                      ${isActive ? 'bg-white/20 text-white' : 'bg-indigo-100 text-indigo-700'}
                    `}>
                      {item.badge}
                    </span>
                  )}
                </button>
              );
            })}
          </nav>
        </div>

        {/* Footer info box */}
        <div className="p-4 m-4 bg-slate-50 border border-slate-200/80 rounded-2xl">
          <div className="flex items-center gap-2 mb-2">
            <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></span>
            <span className="text-xs font-semibold text-slate-700">SMAN 1 Nusantara</span>
          </div>
          <p className="text-[11px] text-slate-500 leading-relaxed">
            Sistem Informasi Sekolah Terpadu Versi 3.2.0 • Status Server KABIN Normal
          </p>
        </div>
      </aside>
    </>
  );
};
