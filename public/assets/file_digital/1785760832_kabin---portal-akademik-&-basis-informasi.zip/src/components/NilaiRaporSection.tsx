import React, { useState } from 'react';
import { GraduationCap, Award, Printer, Download, CheckCircle2, FileSpreadsheet, PlusCircle } from 'lucide-react';
import { MOCK_GRADES } from '../data/mockData';
import { GradeItem, UserRole } from '../types';

interface NilaiRaporSectionProps {
  userRole: UserRole;
}

export const NilaiRaporSection: React.FC<NilaiRaporSectionProps> = ({ userRole }) => {
  const [gradesList, setGradesList] = useState<GradeItem[]>(MOCK_GRADES);
  const [showAddGradeModal, setShowAddGradeModal] = useState(false);
  
  // New grade state for teacher entry
  const [newSubject, setNewSubject] = useState('Fisika Lanjutan');
  const [newScore, setNewScore] = useState(90);

  const avgScore = (
    gradesList.reduce((acc, g) => acc + g.finalGrade, 0) / gradesList.length
  ).toFixed(1);

  const handleAddGrade = (e: React.FormEvent) => {
    e.preventDefault();
    const newItem: GradeItem = {
      subject: newSubject,
      code: 'MAPEL-NEW',
      teacher: 'Ibu Dra. Endang Sri M.Pd',
      kkm: 75,
      tugas: newScore,
      uts: newScore,
      uas: newScore,
      finalGrade: newScore,
      letterGrade: newScore >= 90 ? 'A' : 'B',
      predikat: newScore >= 90 ? 'Sangat Baik' : 'Baik',
      catatan: 'Nilai baru berhasil diinput dari portal KABIN.',
    };
    setGradesList([...gradesList, newItem]);
    setShowAddGradeModal(false);
  };

  return (
    <div className="space-y-6">
      
      {/* Top Header Card */}
      <div className="bg-white p-6 rounded-2xl border border-slate-200/80 shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <GraduationCap className="w-6 h-6 text-indigo-600" />
            <h2 className="text-xl font-extrabold text-slate-900">
              Portal Nilai & Rapor Digital KABIN
            </h2>
          </div>
          <p className="text-xs text-slate-500 mt-1">
            Dimas Anggara Sukma • XII MIPA 1 • Semester Genap 2024/2025
          </p>
        </div>

        <div className="flex items-center gap-3">
          {userRole === 'guru' && (
            <button
              onClick={() => setShowAddGradeModal(true)}
              className="px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-bold flex items-center gap-2 transition-colors"
            >
              <PlusCircle className="w-4 h-4" />
              <span>Input Nilai Siswa</span>
            </button>
          )}

          <button
            onClick={() => window.print()}
            className="px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-xs font-bold flex items-center gap-2 transition-colors"
          >
            <Printer className="w-4 h-4" />
            <span>Cetak Rapor Digital</span>
          </button>
        </div>
      </div>

      {/* Rapor Overview Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="bg-gradient-to-br from-indigo-900 to-slate-900 text-white p-5 rounded-2xl shadow-md">
          <span className="text-xs text-indigo-200 uppercase font-semibold">Rata-Rata Rapor Akhir</span>
          <div className="mt-2 text-3xl font-extrabold">{avgScore}</div>
          <p className="text-xs text-indigo-300 mt-1">Status: Tuntas KKM (75)</p>
        </div>

        <div className="bg-white p-5 rounded-2xl border border-slate-200/80 shadow-xs">
          <span className="text-xs text-slate-500 uppercase font-semibold">Peringkat Kelompok Belajar</span>
          <div className="mt-2 text-3xl font-extrabold text-slate-900">#3</div>
          <p className="text-xs text-emerald-600 font-semibold mt-1">Dari 36 Siswa XII MIPA 1</p>
        </div>

        <div className="bg-white p-5 rounded-2xl border border-slate-200/80 shadow-xs">
          <span className="text-xs text-slate-500 uppercase font-semibold">Sikap & Ekstrakurikuler</span>
          <div className="mt-2 text-3xl font-extrabold text-slate-900">A (Sangat Baik)</div>
          <p className="text-xs text-slate-500 mt-1">Pramuka & KIR Sains</p>
        </div>
      </div>

      {/* Rapor Grades Table */}
      <div className="bg-white rounded-2xl border border-slate-200/80 shadow-xs overflow-hidden">
        <div className="p-5 border-b border-slate-100 flex items-center justify-between">
          <h3 className="text-base font-bold text-slate-900 flex items-center gap-2">
            <FileSpreadsheet className="w-5 h-5 text-indigo-600" />
            Daftar Nilai Hasil Belajar Siswa
          </h3>
          <span className="text-xs font-semibold text-slate-500">
            KKM Sekolah: <strong className="text-slate-800">75.0</strong>
          </span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs text-slate-700">
            <thead className="bg-slate-50 text-slate-500 font-bold uppercase tracking-wider border-b border-slate-200/60">
              <tr>
                <th className="p-4">Mata Pelajaran</th>
                <th className="p-4 text-center">Tugas</th>
                <th className="p-4 text-center">UTS</th>
                <th className="p-4 text-center">UAS</th>
                <th className="p-4 text-center">Nilai Akhir</th>
                <th className="p-4 text-center">Predikat</th>
                <th className="p-4">Catatan Guru</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 font-medium">
              {gradesList.map((g, i) => (
                <tr key={i} className="hover:bg-slate-50/80 transition-colors">
                  <td className="p-4 font-bold text-slate-900">
                    <div>{g.subject}</div>
                    <div className="text-[10px] text-slate-400 font-normal">{g.teacher}</div>
                  </td>
                  <td className="p-4 text-center">{g.tugas}</td>
                  <td className="p-4 text-center">{g.uts}</td>
                  <td className="p-4 text-center">{g.uas}</td>
                  <td className="p-4 text-center font-extrabold text-indigo-600 text-sm">
                    {g.finalGrade}
                  </td>
                  <td className="p-4 text-center">
                    <span className="px-2.5 py-1 rounded-full bg-emerald-100 text-emerald-800 font-bold text-[11px]">
                      {g.letterGrade} ({g.predikat})
                    </span>
                  </td>
                  <td className="p-4 text-slate-600 max-w-xs text-[11px] leading-relaxed">
                    {g.catatan}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Add Grade Modal for Teachers */}
      {showAddGradeModal && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs z-50 flex items-center justify-center p-4">
          <form onSubmit={handleAddGrade} className="bg-white rounded-3xl max-w-md w-full p-6 space-y-4 shadow-2xl">
            <h3 className="font-bold text-slate-900 text-base border-b border-slate-100 pb-2">
              Input Nilai Baru KABIN
            </h3>

            <div>
              <label className="text-xs font-bold text-slate-700">Mata Pelajaran</label>
              <input
                type="text"
                value={newSubject}
                onChange={(e) => setNewSubject(e.target.value)}
                className="w-full mt-1 p-2.5 bg-slate-100 text-xs rounded-xl border border-slate-200"
                required
              />
            </div>

            <div>
              <label className="text-xs font-bold text-slate-700">Nilai Akhir (0 - 100)</label>
              <input
                type="number"
                min="0"
                max="100"
                value={newScore}
                onChange={(e) => setNewScore(Number(e.target.value))}
                className="w-full mt-1 p-2.5 bg-slate-100 text-xs rounded-xl border border-slate-200"
                required
              />
            </div>

            <div className="flex gap-2 pt-2">
              <button
                type="button"
                onClick={() => setShowAddGradeModal(false)}
                className="w-1/2 py-2 rounded-xl bg-slate-100 text-slate-700 text-xs font-bold"
              >
                Batal
              </button>
              <button
                type="submit"
                className="w-1/2 py-2 rounded-xl bg-emerald-600 text-white text-xs font-bold hover:bg-emerald-700"
              >
                Simpan Nilai
              </button>
            </div>
          </form>
        </div>
      )}

    </div>
  );
};
