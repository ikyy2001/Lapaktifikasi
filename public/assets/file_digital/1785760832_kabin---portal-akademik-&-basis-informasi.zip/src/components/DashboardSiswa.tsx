import React from 'react';
import { 
  CalendarDays, 
  GraduationCap, 
  Clock, 
  CheckCircle2, 
  AlertCircle, 
  ArrowRight, 
  FileText, 
  BookOpen, 
  Award,
  Sparkles,
  TrendingUp,
  UserCheck
} from 'lucide-react';
import { UserProfile, ScheduleItem, Assignment, AttendanceRecord } from '../types';
import { MOCK_SCHEDULES, MOCK_ASSIGNMENTS, MOCK_GRADES, MOCK_ATTENDANCE, MOCK_ANNOUNCEMENTS } from '../data/mockData';
import { formatDateIndonesian, getStatusBadgeClass } from '../utils/formatters';

interface DashboardSiswaProps {
  profile: UserProfile;
  onNavigate: (tab: string) => void;
  onOpenAiModal: () => void;
}

export const DashboardSiswa: React.FC<DashboardSiswaProps> = ({
  profile,
  onNavigate,
  onOpenAiModal,
}) => {
  const todaySchedules = MOCK_SCHEDULES.slice(0, 3);
  const pendingAssignments = MOCK_ASSIGNMENTS.filter(a => a.status === 'belum_dikirim');
  const recentAttendance = MOCK_ATTENDANCE[0];

  // Calculate average score
  const avgGrade = (
    MOCK_GRADES.reduce((acc, g) => acc + g.finalGrade, 0) / MOCK_GRADES.length
  ).toFixed(1);

  return (
    <div className="space-y-6">
      
      {/* Welcome Banner Card */}
      <div className="relative overflow-hidden rounded-3xl bg-gradient-to-r from-indigo-900 via-indigo-800 to-slate-900 text-white p-6 sm:p-8 shadow-xl shadow-indigo-950/10">
        <div className="absolute right-0 top-0 bottom-0 w-1/2 opacity-10 pointer-events-none bg-[radial-gradient(#fff_1px,transparent_1px)] [background-size:16px_16px]" />
        
        <div className="relative z-10 flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
          <div className="space-y-2 max-w-xl">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-white/10 backdrop-blur-md border border-white/10 text-xs font-semibold text-indigo-200">
              <Sparkles className="w-3.5 h-3.5 text-amber-300" />
              <span>Selamat Datang Kembali di KABIN</span>
            </div>
            <h2 className="text-2xl sm:text-3xl font-extrabold tracking-tight">
              Halo, {profile.name}! 👋
            </h2>
            <p className="text-slate-300 text-sm leading-relaxed">
              Anda terdaftar di <span className="text-white font-medium">{profile.kelasOrMapel}</span>. 
              Ada <span className="text-amber-300 font-bold">{pendingAssignments.length} tugas belum dikirim</span> dan 1 pengumuman penting hari ini.
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-3">
            <button
              onClick={onOpenAiModal}
              className="px-4 py-2.5 rounded-xl bg-gradient-to-r from-amber-400 to-amber-500 hover:from-amber-500 hover:to-amber-600 text-slate-950 text-sm font-bold shadow-lg shadow-amber-500/20 flex items-center gap-2 transition-all duration-200 hover:scale-[1.02]"
            >
              <Sparkles className="w-4 h-4" />
              <span>Asisten AI KABIN</span>
            </button>
            <button
              onClick={() => onNavigate('jadwal')}
              className="px-4 py-2.5 rounded-xl bg-white/10 hover:bg-white/20 text-white border border-white/15 text-sm font-semibold transition-all duration-200"
            >
              Lihat Jadwal Kelas
            </button>
          </div>
        </div>
      </div>

      {/* Metric Cards Row */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        
        {/* Metric 1: Rata Rata Rapor */}
        <div className="bg-white p-5 rounded-2xl border border-slate-200/80 shadow-xs hover:border-indigo-200 transition-all">
          <div className="flex items-center justify-between">
            <span className="text-xs font-medium text-slate-500 uppercase tracking-wider">Rata-Rata Nilai</span>
            <div className="w-9 h-9 rounded-xl bg-indigo-50 text-indigo-600 flex items-center justify-center">
              <TrendingUp className="w-5 h-5" />
            </div>
          </div>
          <div className="mt-3 flex items-baseline gap-2">
            <span className="text-3xl font-extrabold text-slate-900">{avgGrade}</span>
            <span className="text-xs font-bold text-emerald-600 bg-emerald-50 px-2 py-0.5 rounded-full">
              Predikat A
            </span>
          </div>
          <p className="text-xs text-slate-500 mt-1">Peringkat 3 dari 36 siswa kelas</p>
        </div>

        {/* Metric 2: Kehadiran Presensi */}
        <div className="bg-white p-5 rounded-2xl border border-slate-200/80 shadow-xs hover:border-indigo-200 transition-all">
          <div className="flex items-center justify-between">
            <span className="text-xs font-medium text-slate-500 uppercase tracking-wider">Kehadiran Bulan Ini</span>
            <div className="w-9 h-9 rounded-xl bg-emerald-50 text-emerald-600 flex items-center justify-center">
              <UserCheck className="w-5 h-5" />
            </div>
          </div>
          <div className="mt-3 flex items-baseline gap-2">
            <span className="text-3xl font-extrabold text-slate-900">98.5%</span>
            <span className="text-xs font-bold text-emerald-600 bg-emerald-50 px-2 py-0.5 rounded-full">
              Sangat Rajin
            </span>
          </div>
          <p className="text-xs text-slate-500 mt-1">
            Status Hari Ini: <span className="font-semibold text-emerald-600">{recentAttendance?.status}</span> ({recentAttendance?.timeIn})
          </p>
        </div>

        {/* Metric 3: Tugas Pending */}
        <div className="bg-white p-5 rounded-2xl border border-slate-200/80 shadow-xs hover:border-indigo-200 transition-all">
          <div className="flex items-center justify-between">
            <span className="text-xs font-medium text-slate-500 uppercase tracking-wider">Tugas Menunggu</span>
            <div className="w-9 h-9 rounded-xl bg-amber-50 text-amber-600 flex items-center justify-center">
              <FileText className="w-5 h-5" />
            </div>
          </div>
          <div className="mt-3 flex items-baseline gap-2">
            <span className="text-3xl font-extrabold text-slate-900">{pendingAssignments.length}</span>
            <span className="text-xs font-medium text-amber-700 bg-amber-50 px-2 py-0.5 rounded-full">
              Deadline Dekat
            </span>
          </div>
          <p className="text-xs text-slate-500 mt-1">Matematika Peminatan (5 Ags)</p>
        </div>

        {/* Metric 4: Prestasi & Poin */}
        <div className="bg-white p-5 rounded-2xl border border-slate-200/80 shadow-xs hover:border-indigo-200 transition-all">
          <div className="flex items-center justify-between">
            <span className="text-xs font-medium text-slate-500 uppercase tracking-wider">Poin Karakter & Prestasi</span>
            <div className="w-9 h-9 rounded-xl bg-blue-50 text-blue-600 flex items-center justify-center">
              <Award className="w-5 h-5" />
            </div>
          </div>
          <div className="mt-3 flex items-baseline gap-2">
            <span className="text-3xl font-extrabold text-slate-900">100/100</span>
            <span className="text-xs font-bold text-blue-600 bg-blue-50 px-2 py-0.5 rounded-full">
              Bersih
            </span>
          </div>
          <p className="text-xs text-slate-500 mt-1">Juara 1 Cerdas Cermat Provinsi</p>
        </div>

      </div>

      {/* Main Grid Section: Schedule vs Pending Tasks */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* Left 2 Cols: Schedule for Today */}
        <div className="lg:col-span-2 bg-white rounded-2xl border border-slate-200/80 p-6 shadow-xs">
          <div className="flex items-center justify-between mb-5">
            <div>
              <h3 className="text-base font-bold text-slate-900 flex items-center gap-2">
                <CalendarDays className="w-5 h-5 text-indigo-600" />
                Jadwal Hari Ini (Senin)
              </h3>
              <p className="text-xs text-slate-500 mt-0.5">3 Jam Pelajaran Utama Hari Ini</p>
            </div>
            <button 
              onClick={() => onNavigate('jadwal')}
              className="text-xs font-bold text-indigo-600 hover:text-indigo-800 flex items-center gap-1"
            >
              <span>Lihat Mingguan</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>

          <div className="space-y-3">
            {todaySchedules.map((item) => (
              <div 
                key={item.id}
                className={`p-4 rounded-xl border-l-4 border-y border-r border-slate-100 ${item.color} transition-all duration-200`}
              >
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                  <div>
                    <div className="flex items-center gap-2">
                      <h4 className="font-bold text-slate-900 text-sm">{item.subject}</h4>
                      {item.status === 'berlangsung' && (
                        <span className="inline-flex items-center gap-1 text-[10px] font-bold px-2 py-0.5 rounded-full bg-blue-600 text-white animate-pulse">
                          Sedang Berlangsung
                        </span>
                      )}
                      {item.status === 'selesai' && (
                        <span className="inline-flex items-center gap-1 text-[10px] font-medium px-2 py-0.5 rounded-full bg-slate-200 text-slate-700">
                          Selesai
                        </span>
                      )}
                    </div>
                    <p className="text-xs text-slate-600 mt-1 flex items-center gap-2">
                      <span>{item.teacher}</span>
                      <span>•</span>
                      <span className="font-semibold text-slate-800">{item.room}</span>
                    </p>
                  </div>

                  <div className="flex items-center gap-1.5 text-xs font-bold text-slate-700 bg-white/80 px-3 py-1.5 rounded-lg border border-slate-200/60 self-start sm:self-auto">
                    <Clock className="w-3.5 h-3.5 text-slate-500" />
                    <span>{item.time}</span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Right 1 Col: Urgent Tasks */}
        <div className="bg-white rounded-2xl border border-slate-200/80 p-6 shadow-xs flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between mb-5">
              <h3 className="text-base font-bold text-slate-900 flex items-center gap-2">
                <FileText className="w-5 h-5 text-amber-600" />
                Tugas Perlu Dikirim
              </h3>
              <button 
                onClick={() => onNavigate('tugas')}
                className="text-xs font-bold text-indigo-600 hover:text-indigo-800"
              >
                Semua ({MOCK_ASSIGNMENTS.length})
              </button>
            </div>

            <div className="space-y-3">
              {pendingAssignments.map((asg) => (
                <div key={asg.id} className="p-3.5 rounded-xl bg-slate-50 border border-slate-200/80 space-y-2">
                  <div className="flex items-start justify-between gap-2">
                    <span className="text-[11px] font-bold px-2 py-0.5 rounded-md bg-amber-100 text-amber-800">
                      {asg.subject}
                    </span>
                    <span className="text-[11px] font-medium text-slate-500">
                      {asg.deadline.split(' ')[0]}
                    </span>
                  </div>
                  <h4 className="text-xs font-bold text-slate-800 line-clamp-2">
                    {asg.title}
                  </h4>
                  <p className="text-[11px] text-slate-500">Guru: {asg.teacher}</p>
                </div>
              ))}
            </div>
          </div>

          <button
            onClick={() => onNavigate('tugas')}
            className="mt-5 w-full py-2.5 rounded-xl bg-slate-900 hover:bg-slate-800 text-white text-xs font-semibold flex items-center justify-center gap-2 transition-colors"
          >
            <span>Kirim Jawaban Tugas Sekarang</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>

      </div>

      {/* Latest Announcement Preview */}
      <div className="bg-white rounded-2xl border border-slate-200/80 p-6 shadow-xs">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-base font-bold text-slate-900 flex items-center gap-2">
            <BookOpen className="w-5 h-5 text-indigo-600" />
            Pengumuman Sekolah Terkini
          </h3>
          <button 
            onClick={() => onNavigate('pengumuman')}
            className="text-xs font-bold text-indigo-600 hover:text-indigo-800"
          >
            Lihat Semua Pengumuman
          </button>
        </div>

        {MOCK_ANNOUNCEMENTS.slice(0, 2).map((anc) => (
          <div key={anc.id} className="p-4 rounded-xl bg-indigo-50/50 border border-indigo-100 flex flex-col md:flex-row items-start md:items-center justify-between gap-4 mb-3 last:mb-0">
            <div className="space-y-1">
              <div className="flex items-center gap-2">
                <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-indigo-600 text-white uppercase">
                  {anc.category}
                </span>
                <span className="text-xs font-medium text-slate-500">{anc.date}</span>
              </div>
              <h4 className="text-sm font-bold text-slate-900">{anc.title}</h4>
              <p className="text-xs text-slate-600 line-clamp-1">{anc.summary}</p>
            </div>
            <button 
              onClick={() => onNavigate('pengumuman')}
              className="px-3.5 py-2 rounded-xl bg-white border border-indigo-200 text-indigo-700 text-xs font-bold hover:bg-indigo-100 shrink-0"
            >
              Baca Selengkapnya
            </button>
          </div>
        ))}
      </div>

    </div>
  );
};
