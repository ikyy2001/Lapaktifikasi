import React, { useState } from 'react';
import { 
  Menu, 
  Search, 
  Bell, 
  ChevronDown, 
  UserCheck2, 
  ShieldCheck, 
  Sparkles,
  BookOpen,
  Calendar
} from 'lucide-react';
import { UserProfile, UserRole } from '../types';
import { MOCK_PROFILES } from '../data/mockData';

interface HeaderProps {
  currentProfile: UserProfile;
  setCurrentRole: (role: UserRole) => void;
  onOpenMobileMenu: () => void;
  onOpenNotifications: () => void;
  onOpenAiModal: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  currentProfile,
  setCurrentRole,
  onOpenMobileMenu,
  onOpenNotifications,
  onOpenAiModal,
}) => {
  const [isRoleDropdownOpen, setIsRoleDropdownOpen] = useState(false);

  const rolesList: { role: UserRole; title: string; subtitle: string; badge: string; color: string }[] = [
    { role: 'siswa', title: 'Dimas Anggara', subtitle: 'Siswa • XII MIPA 1', badge: 'SISWA', color: 'bg-indigo-100 text-indigo-700' },
    { role: 'guru', title: 'Ibu Dra. Endang Sri', subtitle: 'Guru & Wali Kelas XII MIPA 1', badge: 'GURU', color: 'bg-emerald-100 text-emerald-700' },
    { role: 'orang_tua', title: 'Bpk. Bambang W.', subtitle: 'Orang Tua Murid', badge: 'ORTU', color: 'bg-amber-100 text-amber-700' },
    { role: 'admin', title: 'Pak Irfan Hakim', subtitle: 'Administrator IT / TU', badge: 'ADMIN', color: 'bg-rose-100 text-rose-700' },
  ];

  return (
    <header className="sticky top-0 z-30 bg-white/90 backdrop-blur-md border-b border-slate-200/80 px-4 lg:px-8 py-3.5">
      <div className="max-w-7xl mx-auto flex items-center justify-between gap-4">
        
        {/* Left Side: Mobile Menu Button & Search */}
        <div className="flex items-center gap-3 flex-1">
          <button
            onClick={onOpenMobileMenu}
            className="lg:hidden p-2 rounded-xl text-slate-600 hover:bg-slate-100 focus:outline-hidden"
          >
            <Menu className="w-5 h-5" />
          </button>

          {/* Search bar */}
          <div className="relative hidden sm:block max-w-md w-full">
            <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
            <input
              type="text"
              placeholder="Cari jadwal, mata pelajaran, guru, atau pengumuman..."
              className="w-full pl-10 pr-4 py-2 bg-slate-100/80 hover:bg-slate-100 focus:bg-white text-sm text-slate-800 placeholder-slate-400 rounded-xl border border-transparent focus:border-indigo-500 focus:outline-hidden transition-all duration-200"
            />
          </div>
        </div>

        {/* Right Side: Quick Action Pills, AI Quick Trigger, Notifications & Role Switcher */}
        <div className="flex items-center gap-2 sm:gap-3">
          {/* AI Helper Button */}
          <button
            onClick={onOpenAiModal}
            className="flex items-center gap-2 px-3 py-1.5 rounded-xl bg-indigo-50 hover:bg-indigo-100 text-indigo-700 border border-indigo-200 text-xs font-semibold transition-all duration-200"
          >
            <Sparkles className="w-4 h-4 text-indigo-600 animate-pulse" />
            <span className="hidden md:inline">Tanya KABIN AI</span>
          </button>

          {/* Academic Term Badge */}
          <div className="hidden xl:flex items-center gap-1.5 px-3 py-1.5 bg-slate-100 rounded-xl text-xs font-medium text-slate-600">
            <Calendar className="w-3.5 h-3.5 text-slate-500" />
            <span>2024/2025 Genap</span>
          </div>

          {/* Notifications Button */}
          <button
            onClick={onOpenNotifications}
            className="relative p-2 rounded-xl text-slate-600 hover:bg-slate-100 hover:text-slate-900 transition-colors"
            title="Notifikasi"
          >
            <Bell className="w-5 h-5" />
            <span className="absolute top-1.5 right-1.5 w-2 h-2 rounded-full bg-rose-500 ring-2 ring-white"></span>
          </button>

          {/* Role Switcher Dropdown */}
          <div className="relative">
            <button
              onClick={() => setIsRoleDropdownOpen(!isRoleDropdownOpen)}
              className="flex items-center gap-2.5 p-1.5 pr-3 rounded-xl hover:bg-slate-100/80 transition-colors border border-transparent hover:border-slate-200"
            >
              <img
                src={currentProfile.avatar}
                alt={currentProfile.name}
                className="w-9 h-9 rounded-xl object-cover ring-2 ring-indigo-500/30"
              />
              <div className="text-left hidden sm:block">
                <div className="flex items-center gap-1.5">
                  <span className="text-sm font-bold text-slate-800 leading-tight">
                    {currentProfile.name.split(' ')[0]} {currentProfile.name.split(' ')[1] || ''}
                  </span>
                  <span className="text-[10px] font-bold px-1.5 py-0.2 rounded-md uppercase bg-indigo-100 text-indigo-700">
                    {currentProfile.role}
                  </span>
                </div>
                <p className="text-[11px] text-slate-500 truncate max-w-[140px]">
                  {currentProfile.kelasOrMapel}
                </p>
              </div>
              <ChevronDown className="w-4 h-4 text-slate-400" />
            </button>

            {/* Dropdown menu */}
            {isRoleDropdownOpen && (
              <>
                <div 
                  className="fixed inset-0 z-10" 
                  onClick={() => setIsRoleDropdownOpen(false)} 
                />
                <div className="absolute right-0 mt-2 w-72 bg-white rounded-2xl shadow-xl border border-slate-200/80 p-2 z-20 animate-in fade-in zoom-in-95 duration-150">
                  <div className="p-3 border-b border-slate-100">
                    <p className="text-xs font-semibold text-slate-400 uppercase tracking-wider">
                      Ganti Mode Peran KABIN
                    </p>
                    <p className="text-[11px] text-slate-500 mt-0.5">
                      Pilih peran untuk menguji antarmuka sistem sekolah
                    </p>
                  </div>

                  <div className="py-1.5 space-y-1">
                    {rolesList.map((item) => (
                      <button
                        key={item.role}
                        onClick={() => {
                          setCurrentRole(item.role);
                          setIsRoleDropdownOpen(false);
                        }}
                        className={`
                          w-full flex items-center justify-between p-2.5 rounded-xl text-left transition-colors
                          ${currentProfile.role === item.role 
                            ? 'bg-indigo-50 text-indigo-900 border border-indigo-200' 
                            : 'hover:bg-slate-50 text-slate-700'}
                        `}
                      >
                        <div>
                          <div className="flex items-center gap-2">
                            <span className="text-xs font-bold text-slate-800">{item.title}</span>
                            <span className={`text-[9px] font-bold px-1.5 py-0.2 rounded-sm ${item.color}`}>
                              {item.badge}
                            </span>
                          </div>
                          <p className="text-[11px] text-slate-500 mt-0.5">{item.subtitle}</p>
                        </div>
                        {currentProfile.role === item.role && (
                          <UserCheck2 className="w-4 h-4 text-indigo-600 shrink-0" />
                        )}
                      </button>
                    ))}
                  </div>

                  <div className="pt-2 border-t border-slate-100 text-center">
                    <span className="text-[11px] text-slate-400">
                      ID Pengguna Active: {currentProfile.nipNis}
                    </span>
                  </div>
                </div>
              </>
            )}
          </div>

        </div>

      </div>
    </header>
  );
};
