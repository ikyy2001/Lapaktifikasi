import React from 'react';
import { Bell, CheckCircle2, Megaphone, Calendar, FileText, X } from 'lucide-react';

interface NotificationDrawerProps {
  isOpen: boolean;
  onClose: () => void;
}

export const NotificationDrawer: React.FC<NotificationDrawerProps> = ({
  isOpen,
  onClose,
}) => {
  if (!isOpen) return null;

  const notifications = [
    {
      id: 'n1',
      title: 'Tugas Matematika Peminatan Ditambahkan',
      desc: 'Ibu Dra. Endang Sri memberikan tugas Vektor 3D (Deadline: 05 Agustus 2026)',
      time: '10 Menit yang lalu',
      type: 'tugas',
      unread: true,
    },
    {
      id: 'n2',
      title: 'Presensi Fingerprint Terverifikasi',
      desc: 'Dimas Anggara Sukma tercatat HADIR pada pukul 06.45 WIB',
      time: '2 Jam yang lalu',
      type: 'presensi',
      unread: true,
    },
    {
      id: 'n3',
      title: 'Pengumuman PTS Genap 2024/2025',
      desc: 'Jadwal Penilaian Tengah Semester telah dirilis oleh Kurikulum Sekolah',
      time: 'Kemarin, 14.30 WIB',
      type: 'pengumuman',
      unread: false,
    },
    {
      id: 'n4',
      title: 'Pembayaran SPP Bulan Juli Lunas',
      desc: 'Transaksi Virtual Account Mandiri berhasil diverifikasi sistem KABIN Pay',
      time: '03 Juli 2026',
      type: 'keuangan',
      unread: false,
    }
  ];

  return (
    <div className="fixed inset-0 bg-slate-900/50 backdrop-blur-xs z-50 flex justify-end">
      <div className="bg-white w-full max-w-sm h-full p-6 space-y-5 shadow-2xl flex flex-col justify-between animate-in slide-in-from-right duration-200">
        
        <div>
          <div className="flex items-center justify-between border-b border-slate-100 pb-4">
            <div className="flex items-center gap-2">
              <Bell className="w-5 h-5 text-indigo-600" />
              <h3 className="font-extrabold text-slate-900 text-base">Notifikasi KABIN</h3>
            </div>
            <button onClick={onClose} className="text-slate-400 hover:text-slate-600 font-bold">
              <X className="w-5 h-5" />
            </button>
          </div>

          <div className="mt-4 space-y-3">
            {notifications.map((n) => (
              <div 
                key={n.id}
                className={`p-3.5 rounded-xl border transition-all space-y-1 ${n.unread ? 'bg-indigo-50/50 border-indigo-200' : 'bg-slate-50 border-slate-200/60'}`}
              >
                <div className="flex items-center justify-between">
                  <span className="font-bold text-xs text-slate-900">{n.title}</span>
                  {n.unread && <span className="w-2 h-2 rounded-full bg-indigo-600"></span>}
                </div>
                <p className="text-xs text-slate-600">{n.desc}</p>
                <span className="text-[10px] text-slate-400 block pt-1">{n.time}</span>
              </div>
            ))}
          </div>
        </div>

        <button
          onClick={onClose}
          className="w-full py-2.5 rounded-xl bg-slate-900 text-white font-bold text-xs"
        >
          Tandai Semua Sudah Dibaca
        </button>

      </div>
    </div>
  );
};
