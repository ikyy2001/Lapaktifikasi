import React, { useState } from 'react';
import { Sparkles, Send, Bot, User, RefreshCw, X, BookOpen, Lightbulb } from 'lucide-react';
import { askKabinAi } from '../services/geminiService';
import { ChatMessage, UserRole } from '../types';

interface AiAsistenModalProps {
  isOpen: boolean;
  onClose: () => void;
  userRole: UserRole;
}

export const AiAsistenModal: React.FC<AiAsistenModalProps> = ({
  isOpen,
  onClose,
  userRole,
}) => {
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: 'msg-init',
      sender: 'ai',
      text: `Halo! Saya **KABIN AI Asisten**, pendamping akademis cerdas Anda di SMAN 1 Nusantara.\n\nApa yang ingin Anda pelajari atau siapkan hari ini? Silakan pilih topik di bawah atau ketik pertanyaan langsung!`,
      timestamp: 'Baru Saja',
    }
  ]);
  const [inputPrompt, setInputPrompt] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  if (!isOpen) return null;

  const quickPrompts = userRole === 'guru' ? [
    'Buat RPP Kurikulum Merdeka Matematika Kalkulus XII',
    'Buatkan 5 Soal HOTS Kimia Larutan Penyangga',
    'Format kalimat catatan rapor sikap kepemimpinan'
  ] : [
    'Jelaskan konsep mudah Vektor 3 Dimensi',
    'Bagaimana cara menghitung Integral Tentu?',
    'Tips strategi lolos jalur SNBP Kedokteran/FTI 2026'
  ];

  const handleSendMessage = async (textToSend?: string) => {
    const prompt = textToSend || inputPrompt;
    if (!prompt.trim() || isLoading) return;

    const userMsg: ChatMessage = {
      id: `usr-${Date.now()}`,
      sender: 'user',
      text: prompt,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    };

    setMessages(prev => [...prev, userMsg]);
    setInputPrompt('');
    setIsLoading(true);

    try {
      const aiReplyText = await askKabinAi(prompt, userRole);
      const aiMsg: ChatMessage = {
        id: `ai-${Date.now()}`,
        sender: 'ai',
        text: aiReplyText,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      };
      setMessages(prev => [...prev, aiMsg]);
    } catch (err) {
      console.error('AI Error:', err);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 bg-slate-950/70 backdrop-blur-md z-50 flex items-center justify-center p-3 sm:p-6">
      <div className="bg-white rounded-3xl max-w-2xl w-full h-[85vh] flex flex-col justify-between shadow-2xl overflow-hidden animate-in zoom-in-95 border border-slate-200">
        
        {/* Header */}
        <div className="p-4 sm:p-5 bg-gradient-to-r from-indigo-900 via-indigo-800 to-slate-900 text-white flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-amber-400 text-slate-950 flex items-center justify-center font-bold shadow-md">
              <Sparkles className="w-6 h-6 animate-spin-slow" />
            </div>
            <div>
              <h3 className="font-extrabold text-base tracking-tight flex items-center gap-2">
                KABIN AI Asisten
                <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-white/20 uppercase">
                  Gemini 2.5
                </span>
              </h3>
              <p className="text-xs text-indigo-200">
                Pusat Bantuan Akademis & Generatif SMAN 1 Nusantara
              </p>
            </div>
          </div>

          <button 
            onClick={onClose}
            className="p-2 rounded-xl bg-white/10 hover:bg-white/20 text-white transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Quick Suggestion Chips */}
        <div className="bg-slate-100/80 px-4 py-2.5 border-b border-slate-200/80 flex items-center gap-2 overflow-x-auto scrollbar-none">
          <span className="text-[11px] font-bold text-slate-400 whitespace-nowrap flex items-center gap-1">
            <Lightbulb className="w-3.5 h-3.5 text-amber-500" />
            Saran Prompt:
          </span>
          {quickPrompts.map((p, idx) => (
            <button
              key={idx}
              onClick={() => handleSendMessage(p)}
              className="px-3 py-1 rounded-full bg-white hover:bg-indigo-50 text-indigo-900 border border-slate-200 hover:border-indigo-200 text-xs font-semibold whitespace-nowrap shadow-xs transition-all"
            >
              {p}
            </button>
          ))}
        </div>

        {/* Chat Messages Log */}
        <div className="p-4 sm:p-6 flex-1 overflow-y-auto space-y-4">
          {messages.map((msg) => (
            <div
              key={msg.id}
              className={`flex gap-3 ${msg.sender === 'user' ? 'justify-end' : 'justify-start'}`}
            >
              {msg.sender === 'ai' && (
                <div className="w-8 h-8 rounded-xl bg-indigo-600 text-white flex items-center justify-center shrink-0 shadow-sm mt-1">
                  <Bot className="w-4 h-4" />
                </div>
              )}

              <div className={`
                max-w-[82%] p-4 rounded-2xl text-xs leading-relaxed space-y-2
                ${msg.sender === 'user' 
                  ? 'bg-indigo-600 text-white rounded-br-none shadow-sm' 
                  : 'bg-slate-100 text-slate-800 rounded-bl-none border border-slate-200/80'}
              `}>
                <div className="whitespace-pre-line">{msg.text}</div>
                <div className={`text-[9px] font-medium text-right ${msg.sender === 'user' ? 'text-indigo-200' : 'text-slate-400'}`}>
                  {msg.timestamp}
                </div>
              </div>

              {msg.sender === 'user' && (
                <div className="w-8 h-8 rounded-xl bg-slate-900 text-white flex items-center justify-center shrink-0 shadow-sm mt-1">
                  <User className="w-4 h-4" />
                </div>
              )}
            </div>
          ))}

          {isLoading && (
            <div className="flex items-center gap-2 text-xs font-semibold text-indigo-600 p-3 bg-indigo-50 rounded-2xl w-fit animate-pulse">
              <RefreshCw className="w-4 h-4 animate-spin" />
              <span>KABIN AI sedang memproses jawaban...</span>
            </div>
          )}
        </div>

        {/* Input Box */}
        <div className="p-3 sm:p-4 bg-white border-t border-slate-200/80">
          <form 
            onSubmit={(e) => {
              e.preventDefault();
              handleSendMessage();
            }}
            className="flex items-center gap-2"
          >
            <input
              type="text"
              value={inputPrompt}
              onChange={(e) => setInputPrompt(e.target.value)}
              placeholder="Ketik pertanyaan atau tugas yang ingin diselesaikan..."
              className="flex-1 px-4 py-3 bg-slate-100 text-xs font-medium text-slate-900 rounded-xl border border-transparent focus:border-indigo-500 focus:bg-white focus:outline-hidden transition-all"
            />
            <button
              type="submit"
              disabled={isLoading || !inputPrompt.trim()}
              className="px-4 py-3 bg-indigo-600 hover:bg-indigo-700 disabled:opacity-50 text-white rounded-xl text-xs font-bold flex items-center gap-1.5 shadow-md transition-all shrink-0"
            >
              <span>Kirim</span>
              <Send className="w-4 h-4" />
            </button>
          </form>
        </div>

      </div>
    </div>
  );
};
