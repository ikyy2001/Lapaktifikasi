import React from 'react';
import { 
  Heart, 
  UserCheck, 
  CreditCard, 
  GraduationCap, 
  MessageSquare, 
  CheckCircle2, 
  ArrowRight,
  ShieldCheck,
  AlertCircle
} from 'lucide-react';
import { UserProfile } from '../types';
import { MOCK_ATTENDANCE, MOCK_GRADES, MOCK_PAYMENTS } from '../data/mockData';
import { formatRupiah, formatDateIndonesian } from '../utils/formatters';

interface DashboardOrangTuaProps {
  profile: UserProfile;
  onNavigate: (tab: string) => void;
}

export const DashboardOrangTua: React.FC<DashboardOrangTuaProps> = ({
  profile,
  onNavigate,
}) => {
  const latestAttendance = MOCK_ATTENDANCE[0];
  const unpaidSpp = MOCK_PAYMENTS.find(p => p.status === 'belum_bayar');

  const avgGrade = (
    MOCK_GRADES.reduce((acc, g) => acc + g.finalGrade, 0) / MOCK_GRADES.length
  ).toFixed(1);

  return (
    <div className="space-y-6">
      
      {/* Parent Header Banner */}
      <div className="relative overflow-hidden rounded-3xl bg-gradient-to-r from-amber-900 via-amber-800 to-slate-900 text-white p-6 sm:p-8 shadow-xl shadow-amber-950/10">
        <div className="relative z-10 flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
          <div className="space-y-2 max-w-xl">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-white/10 backdrop-blur-md border border-white/10 text-xs font-semibold text-amber-200">
              <Heart className="w-3.5 h-3.5 text-rose-400 fill-rose-400" />
              <span>Portal Wali Murid KABIN</span>
            </div>
            <h2 className="text-2xl sm:text-3xl font-extrabold tracking-tight">
              Selamat Datang, {profile.name}!
            </h2>
            <p className="text-amber-100 text-sm leading-relaxed">
              Memantau perkembangan akademis & kehadiran <span className="font-bold text-white">Dimas Anggara Sukma (XII MIPA 1)</span> secara komprehensif.
            </p>
          </div>

          <div className="flex items-center gap-3">
            <button
              onClick={() => onNavigate('keuangan')}
              className="px-4 py-2.5 rounded-xl bg-amber-400 hover:bg-amber-500 text-slate-950 font-bold text-sm shadow-lg flex items-center gap-2 transition-all hover:scale-[1.02]"
            >
              <CreditCard className="w-4 h-4" />
              <span>Bayar SPP Bulan Ini</span>
            </button>
          </div>
        </div>
      </div>

      {/* Metrics Row */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        
        {/* Metric 1: Kehadiran Hari Ini */}
        <div className="bg-white p-5 rounded-2xl border border-slate-200/80 shadow-xs">
          <div className="flex items-center justify-between">
            <span className="text-xs font-medium text-slate-500 uppercase tracking-wider">Status Kehadiran Hari Ini</span>
            <div className="w-9 h-9 rounded-xl bg-emerald-50 text-emerald-600 flex items-center justify-center">
              <UserCheck className="w-5 h-5" />
            </div>
          </div>
          <div className="mt-3 flex items-baseline gap-2">
            <span className="text-2xl font-extrabold text-slate-900">{latestAttendance.status}</span>
            <span className="text-xs font-bold text-emerald-600 bg-emerald-50 px-2 py-0.5 rounded-full">
              {latestAttendance.timeIn}
            </span>
          </div>
          <p className="text-xs text-slate-500 mt-1">Presensi otomatis via Mesin Fingerprint KABIN</p>
        </div>

        {/* Metric 2: Rata-Rata Nilai */}
        <div className="bg-white p-5 rounded-2xl border border-slate-200/80 shadow-xs">
          <div className="flex items-center justify-between">
            <span className="text-xs font-medium text-slate-500 uppercase tracking-wider">Rata-Rata Rapor Anak</span>
            <div className="w-9 h-9 rounded-xl bg-indigo-50 text-indigo-600 flex items-center justify-center">
              <GraduationCap className="w-5 h-5" />
            </div>
          </div>
          <div className="mt-3 flex items-baseline gap-2">
            <span className="text-2xl font-extrabold text-slate-900">{avgGrade}</span>
            <span className="text-xs font-bold text-indigo-600 bg-indigo-50 px-2 py-0.5 rounded-full">
              Peringkat 3 Kelas
            </span>
          </div>
          <p className="text-xs text-slate-500 mt-1">Capaian Kurikulum Merdeka Terlampaui</p>
        </div>

        {/* Metric 3: Status Tagihan */}
        <div className="bg-white p-5 rounded-2xl border border-slate-200/80 shadow-xs">
          <div className="flex items-center justify-between">
            <span className="text-xs font-medium text-slate-500 uppercase tracking-wider">Tagihan SPP Belum Dibayar</span>
            <div className="w-9 h-9 rounded-xl bg-amber-50 text-amber-600 flex items-center justify-center">
              <CreditCard className="w-5 h-5" />
            </div>
          </div>
          <div className="mt-3 flex items-baseline gap-2">
            <span className="text-2xl font-extrabold text-slate-900">
              {unpaidSpp ? formatRupiah(unpaidSpp.amount) : 'Rp 0'}
            </span>
            <span className="text-xs font-bold text-amber-700 bg-amber-50 px-2 py-0.5 rounded-full">
              {unpaidSpp ? unpaidSpp.month : 'Lunas'}
            </span>
          </div>
          <p className="text-xs text-slate-500 mt-1">
            Jatuh Tempo: {unpaidSpp ? unpaidSpp.dueDate : '-'}
          </p>
        </div>

      </div>

      {/* Middle Grid: Wali Kelas Contact & Grade Summary */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* Child Academic Overview */}
        <div className="lg:col-span-2 bg-white rounded-2xl border border-slate-200/80 p-6 shadow-xs">
          <div className="flex items-center justify-between mb-5">
            <div>
              <h3 className="text-base font-bold text-slate-900">
                Laporan Nilai Mata Pelajaran Utama
              </h3>
              <p className="text-xs text-slate-500 mt-0.5">Penilaian Hasil Belajar Dimas Anggara</p>
            </div>
            <button 
              onClick={() => onNavigate('nilai')}
              className="text-xs font-bold text-indigo-600 hover:text-indigo-800"
            >
              Buka Rapor Digital
            </button>
          </div>

          <div className="divide-y divide-slate-100">
            {MOCK_GRADES.slice(0, 4).map((item, idx) => (
              <div key={idx} className="py-3 flex items-center justify-between gap-4">
                <div>
                  <h4 className="font-bold text-slate-800 text-xs">{item.subject}</h4>
                  <p className="text-[11px] text-slate-500">{item.teacher}</p>
                </div>
                <div className="flex items-center gap-3">
                  <span className="text-xs font-extrabold text-slate-900">{item.finalGrade}</span>
                  <span className="text-[11px] font-bold px-2 py-0.5 rounded-md bg-indigo-100 text-indigo-700">
                    {item.letterGrade} ({item.predikat})
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Contact Wali Kelas Card */}
        <div className="bg-white rounded-2xl border border-slate-200/80 p-6 shadow-xs flex flex-col justify-between">
          <div className="space-y-4">
            <h3 className="text-base font-bold text-slate-900 flex items-center gap-2">
              <MessageSquare className="w-5 h-5 text-indigo-600" />
              Wali Kelas Dimas
            </h3>

            <div className="p-4 rounded-xl bg-slate-50 border border-slate-200/80 flex items-center gap-3">
              <img
                src="https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=100&auto=format&fit=crop&q=80"
                alt="Wali Kelas"
                className="w-12 h-12 rounded-xl object-cover ring-2 ring-indigo-500/20"
              />
              <div>
                <h4 className="font-bold text-slate-900 text-xs">Ibu Dra. Endang Sri M.Pd</h4>
                <p className="text-[11px] text-slate-500">Wali Kelas XII MIPA 1</p>
                <p className="text-[10px] font-semibold text-emerald-600 mt-0.5">● Online jam kerja sekolah</p>
              </div>
            </div>

            <p className="text-xs text-slate-600 leading-relaxed">
              Anda dapat berdiskusi mengenai catatan kehadiran, sikap, maupun perkembangan akademis anak dengan Wali Kelas.
            </p>
          </div>

          <a
            href="https://wa.me/6281398765432"
            target="_blank"
            rel="noopener noreferrer"
            className="mt-5 w-full py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs flex items-center justify-center gap-2 transition-colors"
          >
            <MessageSquare className="w-4 h-4" />
            <span>Kirim Pesan WhatsApp Ke Wali Kelas</span>
          </a>
        </div>

      </div>

    </div>
  );
};
