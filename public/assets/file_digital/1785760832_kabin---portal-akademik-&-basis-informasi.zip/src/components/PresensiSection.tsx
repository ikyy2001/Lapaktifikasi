import React, { useState } from 'react';
import { UserCheck, Calendar, FileText, CheckCircle2, Clock, Upload, Plus } from 'lucide-react';
import { MOCK_ATTENDANCE } from '../data/mockData';
import { AttendanceRecord } from '../types';
import { getStatusBadgeClass } from '../utils/formatters';

export const PresensiSection: React.FC = () => {
  const [attendanceList, setAttendanceList] = useState<AttendanceRecord[]>(MOCK_ATTENDANCE);
  const [showIzinModal, setShowIzinModal] = useState(false);

  // Leave Form state
  const [leaveType, setLeaveType] = useState<'Izin' | 'Sakit'>('Izin');
  const [leaveDate, setLeaveDate] = useState('2026-08-10');
  const [leaveNotes, setLeaveNotes] = useState('');
  const [fileName, setFileName] = useState<string | null>(null);

  const handleSubmitLeave = (e: React.FormEvent) => {
    e.preventDefault();
    const newRecord: AttendanceRecord = {
      id: `att-${Date.now()}`,
      date: leaveDate,
      day: 'Senin',
      timeIn: '-',
      timeOut: '-',
      status: leaveType,
      notes: leaveNotes || (leaveType === 'Sakit' ? 'Surat Dokter Terlampir' : 'Izin Keperluan Keluarga'),
    };

    setAttendanceList([newRecord, ...attendanceList]);
    setShowIzinModal(false);
    setLeaveNotes('');
    setFileName(null);
  };

  return (
    <div className="space-y-6">
      
      {/* Top Banner */}
      <div className="bg-white p-6 rounded-2xl border border-slate-200/80 shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-extrabold text-slate-900 flex items-center gap-2">
            <UserCheck className="w-6 h-6 text-indigo-600" />
            Presensi & Kehadiran Digital KABIN
          </h2>
          <p className="text-xs text-slate-500 mt-1">
            Rekam kehadiran otomatis terintegrasi dengan Kartu Pelajar Digital & Mesin Tap Sekolah
          </p>
        </div>

        <button
          onClick={() => setShowIzinModal(true)}
          className="px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-xs font-bold flex items-center gap-2 transition-colors self-start md:self-auto"
        >
          <Plus className="w-4 h-4" />
          <span>Ajukan Surat Izin / Sakit</span>
        </button>
      </div>

      {/* Attendance Stats Row */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
        <div className="bg-white p-4 rounded-2xl border border-slate-200/80 text-center">
          <span className="text-xs text-slate-500 uppercase font-semibold">Hadir Tepat Waktu</span>
          <div className="text-2xl font-extrabold text-emerald-600 mt-1">98.5%</div>
        </div>

        <div className="bg-white p-4 rounded-2xl border border-slate-200/80 text-center">
          <span className="text-xs text-slate-500 uppercase font-semibold">Izin Diterima</span>
          <div className="text-2xl font-extrabold text-amber-600 mt-1">1 Hari</div>
        </div>

        <div className="bg-white p-4 rounded-2xl border border-slate-200/80 text-center">
          <span className="text-xs text-slate-500 uppercase font-semibold">Sakit</span>
          <div className="text-2xl font-extrabold text-blue-600 mt-1">0 Hari</div>
        </div>

        <div className="bg-white p-4 rounded-2xl border border-slate-200/80 text-center">
          <span className="text-xs text-slate-500 uppercase font-semibold">Alpha / Tanpa Ket.</span>
          <div className="text-2xl font-extrabold text-rose-600 mt-1">0 Hari</div>
        </div>
      </div>

      {/* Attendance History Log */}
      <div className="bg-white rounded-2xl border border-slate-200/80 shadow-xs p-6 space-y-4">
        <h3 className="text-base font-bold text-slate-900 flex items-center gap-2">
          <Calendar className="w-5 h-5 text-indigo-600" />
          Riwayat Kehadiran Harian Siswa
        </h3>

        <div className="space-y-3">
          {attendanceList.map((rec) => (
            <div 
              key={rec.id}
              className="p-4 rounded-xl bg-slate-50 border border-slate-200/80 flex flex-col sm:flex-row sm:items-center justify-between gap-3"
            >
              <div className="space-y-1">
                <div className="flex items-center gap-2">
                  <span className="font-bold text-slate-900 text-xs">
                    {rec.day}, {rec.date}
                  </span>
                  <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full border ${getStatusBadgeClass(rec.status)}`}>
                    {rec.status}
                  </span>
                </div>
                <p className="text-xs text-slate-500">{rec.notes}</p>
              </div>

              <div className="flex items-center gap-4 text-xs text-slate-600 self-start sm:self-auto">
                <div>
                  <span className="text-[10px] text-slate-400 block">Jam Masuk</span>
                  <span className="font-bold text-slate-800">{rec.timeIn}</span>
                </div>
                <div>
                  <span className="text-[10px] text-slate-400 block">Jam Pulang</span>
                  <span className="font-bold text-slate-800">{rec.timeOut}</span>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Leave Application Modal */}
      {showIzinModal && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs z-50 flex items-center justify-center p-4">
          <form onSubmit={handleSubmitLeave} className="bg-white rounded-3xl max-w-md w-full p-6 space-y-4 shadow-2xl">
            <h3 className="font-bold text-slate-900 text-base border-b border-slate-100 pb-2">
              Pengajuan Surat Izin / Ketidakhadiran
            </h3>

            <div>
              <label className="text-xs font-bold text-slate-700">Kategori Izin</label>
              <select
                value={leaveType}
                onChange={(e) => setLeaveType(e.target.value as 'Izin' | 'Sakit')}
                className="w-full mt-1 p-2.5 bg-slate-100 text-xs rounded-xl border border-slate-200"
              >
                <option value="Izin">Izin (Keperluan Resmi / Keluarga)</option>
                <option value="Sakit">Sakit (Dokter / Rawat Jalan)</option>
              </select>
            </div>

            <div>
              <label className="text-xs font-bold text-slate-700">Tanggal Ketidakhadiran</label>
              <input
                type="date"
                value={leaveDate}
                onChange={(e) => setLeaveDate(e.target.value)}
                className="w-full mt-1 p-2.5 bg-slate-100 text-xs rounded-xl border border-slate-200"
                required
              />
            </div>

            <div>
              <label className="text-xs font-bold text-slate-700">Alasan / Keterangan Singkat</label>
              <textarea
                value={leaveNotes}
                onChange={(e) => setLeaveNotes(e.target.value)}
                placeholder="Contoh: Mengikuti Lomba Cerdas Cermat Sains Tingkat Provinsi"
                className="w-full mt-1 p-2.5 bg-slate-100 text-xs rounded-xl border border-slate-200 h-20"
                required
              />
            </div>

            {/* File Upload Dropzone */}
            <div>
              <label className="text-xs font-bold text-slate-700">Unggah Lampiran (Surat Dokter/Izin PDF/JPG)</label>
              <div 
                onClick={() => setFileName('Surat_Izin_Resmi_Signed.pdf')}
                className="mt-1 p-4 border-2 border-dashed border-indigo-200 bg-indigo-50/50 hover:bg-indigo-50 rounded-xl text-center cursor-pointer transition-colors"
              >
                <Upload className="w-6 h-6 text-indigo-600 mx-auto mb-1" />
                <span className="text-xs font-semibold text-indigo-900">
                  {fileName ? fileName : 'Klik untuk Unggah Berkas Bukti (Max 5MB)'}
                </span>
              </div>
            </div>

            <div className="flex gap-2 pt-2">
              <button
                type="button"
                onClick={() => setShowIzinModal(false)}
                className="w-1/2 py-2.5 rounded-xl bg-slate-100 text-slate-700 text-xs font-bold"
              >
                Batal
              </button>
              <button
                type="submit"
                className="w-1/2 py-2.5 rounded-xl bg-indigo-600 text-white text-xs font-bold hover:bg-indigo-700"
              >
                Kirim Pengajuan
              </button>
            </div>
          </form>
        </div>
      )}

    </div>
  );
};
