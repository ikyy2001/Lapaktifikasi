import React, { useState } from 'react';
import { CalendarDays, Clock, MapPin, User, Download, Filter, CheckCircle2 } from 'lucide-react';
import { MOCK_SCHEDULES } from '../data/mockData';
import { ScheduleItem } from '../types';

export const JadwalSection: React.FC = () => {
  const [selectedDay, setSelectedDay] = useState<string>('Senin');

  const days = ['Senin', 'Selasa', 'Rabu', 'Kamis', 'Jumat', 'Sabtu'];

  const filteredSchedules = MOCK_SCHEDULES.filter(s => s.day === selectedDay);

  const academicCalendarEvents = [
    { date: '18 - 25 Agustus 2026', title: 'Penilaian Tengah Semester (PTS) Genap', category: 'Ujian' },
    { date: '17 Agustus 2026', title: 'Upacara HUT Kemerdekaan RI Ke-81', category: 'Nasional' },
    { date: '01 September 2026', title: 'Pameran Karya Inovasi Sains & Bioteknologi', category: 'Kegiatan' },
    { date: '12 - 18 Oktober 2026', title: 'Penilaian Akhir Semester (PAS) Genap', category: 'Ujian' },
  ];

  return (
    <div className="space-y-6">
      
      {/* Top Banner */}
      <div className="bg-white p-6 rounded-2xl border border-slate-200/80 shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-extrabold text-slate-900 flex items-center gap-2">
            <CalendarDays className="w-6 h-6 text-indigo-600" />
            Jadwal Pelajaran & Kalender Akademik
          </h2>
          <p className="text-xs text-slate-500 mt-1">
            Kelas XII MIPA 1 • Tahun Ajaran 2024/2025 Semester Genap
          </p>
        </div>

        <button 
          onClick={() => alert('Mengunduh Jadwal Pelajaran PDF (Jadwal_XII_MIPA1_KABIN.pdf)...')}
          className="px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-xs font-bold flex items-center gap-2 transition-colors self-start md:self-auto"
        >
          <Download className="w-4 h-4" />
          <span>Unduh Jadwal (PDF)</span>
        </button>
      </div>

      {/* Day Filter Pills */}
      <div className="flex items-center gap-2 overflow-x-auto pb-1 scrollbar-none">
        {days.map((day) => (
          <button
            key={day}
            onClick={() => setSelectedDay(day)}
            className={`
              px-5 py-2.5 rounded-xl text-xs font-bold transition-all shrink-0
              ${selectedDay === day 
                ? 'bg-indigo-600 text-white shadow-md shadow-indigo-200' 
                : 'bg-white text-slate-600 hover:bg-slate-100 border border-slate-200/80'}
            `}
          >
            {day}
          </button>
        ))}
      </div>

      {/* Schedule Grid & Academic Calendar split */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* Schedule List */}
        <div className="lg:col-span-2 space-y-3">
          {filteredSchedules.length > 0 ? (
            filteredSchedules.map((item) => (
              <div 
                key={item.id}
                className="bg-white p-5 rounded-2xl border border-slate-200/80 shadow-xs hover:border-indigo-200 transition-all space-y-3"
              >
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-100 pb-3">
                  <div>
                    <h3 className="text-base font-bold text-slate-900">{item.subject}</h3>
                    <p className="text-xs text-slate-500 flex items-center gap-1.5 mt-0.5">
                      <User className="w-3.5 h-3.5 text-slate-400" />
                      <span>{item.teacher}</span>
                    </p>
                  </div>

                  <div className="flex items-center gap-2">
                    <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-lg bg-indigo-50 text-indigo-700 text-xs font-bold border border-indigo-100">
                      <Clock className="w-3.5 h-3.5" />
                      {item.time}
                    </span>
                  </div>
                </div>

                <div className="flex items-center justify-between text-xs text-slate-600 pt-1">
                  <span className="flex items-center gap-1.5 font-medium">
                    <MapPin className="w-3.5 h-3.5 text-slate-400" />
                    {item.room}
                  </span>
                  
                  <span className="text-[11px] font-semibold text-emerald-600 flex items-center gap-1">
                    <CheckCircle2 className="w-3.5 h-3.5" />
                    Status Roster Aktif
                  </span>
                </div>
              </div>
            ))
          ) : (
            <div className="bg-white p-12 rounded-2xl border border-slate-200/80 text-center space-y-3">
              <CalendarDays className="w-10 h-10 text-slate-300 mx-auto" />
              <h4 className="text-sm font-bold text-slate-700">Tidak Ada Jadwal KBL Hari {selectedDay}</h4>
              <p className="text-xs text-slate-500 max-w-sm mx-auto">
                Hari ini dialokasikan untuk kegiatan ekstrakurikuler, bimbingan olimpiade, atau belajar mandiri.
              </p>
            </div>
          )}
        </div>

        {/* Academic Calendar Widget */}
        <div className="bg-white p-6 rounded-2xl border border-slate-200/80 shadow-xs space-y-4">
          <h3 className="text-base font-bold text-slate-900">Agenda & Kalender Akademik</h3>
          <p className="text-xs text-slate-500">Jadwal kegiatan penting semester ini</p>

          <div className="space-y-3">
            {academicCalendarEvents.map((evt, idx) => (
              <div key={idx} className="p-3.5 rounded-xl bg-slate-50 border border-slate-200/60 space-y-1.5">
                <div className="flex items-center justify-between">
                  <span className="text-[10px] font-bold px-2 py-0.5 rounded-md bg-indigo-100 text-indigo-800 uppercase">
                    {evt.category}
                  </span>
                  <span className="text-[11px] font-medium text-slate-500">{evt.date}</span>
                </div>
                <h4 className="text-xs font-bold text-slate-800">{evt.title}</h4>
              </div>
            ))}
          </div>
        </div>

      </div>

    </div>
  );
};
