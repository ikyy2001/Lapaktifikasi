import React, { useState } from 'react';
import { CreditCard, CheckCircle2, Download, Copy, QrCode, ShieldCheck } from 'lucide-react';
import { MOCK_PAYMENTS } from '../data/mockData';
import { PaymentItem } from '../types';
import { formatRupiah, getStatusBadgeClass, getStatusLabel } from '../utils/formatters';

export const KeuanganSection: React.FC = () => {
  const [payments, setPayments] = useState<PaymentItem[]>(MOCK_PAYMENTS);
  const [selectedPay, setSelectedPay] = useState<PaymentItem | null>(null);
  const [copiedVa, setCopiedVa] = useState(false);

  const handleCopyVa = (va: string) => {
    navigator.clipboard.writeText(va);
    setCopiedVa(true);
    setTimeout(() => setCopiedVa(false), 2000);
  };

  const handleConfirmPayment = () => {
    if (!selectedPay) return;
    const updated = payments.map(p => {
      if (p.id === selectedPay.id) {
        return {
          ...p,
          status: 'lunas' as const,
          paymentDate: '02 Agustus 2026',
          paymentMethod: 'KABIN Pay Virtual Account Auto-Debet'
        };
      }
      return p;
    });
    setPayments(updated);
    setSelectedPay(null);
  };

  return (
    <div className="space-y-6">
      
      {/* Top Header Card */}
      <div className="bg-white p-6 rounded-2xl border border-slate-200/80 shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-extrabold text-slate-900 flex items-center gap-2">
            <CreditCard className="w-6 h-6 text-indigo-600" />
            Keuangan & SPP Sekolah (KABIN Pay)
          </h2>
          <p className="text-xs text-slate-500 mt-1">
            Status tagihan bulanan SPP Dimas Anggara Sukma (NISN: 0068912344)
          </p>
        </div>

        <div className="flex items-center gap-2 text-xs font-bold text-slate-700 bg-slate-100 px-3 py-1.5 rounded-xl">
          <ShieldCheck className="w-4 h-4 text-emerald-600" />
          <span>Tergabung Sistem Pembayaran Bank Jateng & Mandiri</span>
        </div>
      </div>

      {/* Payment Cards Grid */}
      <div className="space-y-4">
        <h3 className="text-base font-bold text-slate-900">Rincian Tagihan Bulan Ini</h3>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {payments.map((p) => (
            <div 
              key={p.id}
              className={`
                bg-white p-6 rounded-2xl border transition-all shadow-xs flex flex-col justify-between space-y-4
                ${p.status === 'belum_bayar' ? 'border-amber-300 ring-2 ring-amber-500/10' : 'border-slate-200/80'}
              `}
            >
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-extrabold text-slate-900">{p.month}</span>
                  <span className={`text-[10px] font-bold px-2.5 py-0.5 rounded-full border ${getStatusBadgeClass(p.status)}`}>
                    {getStatusLabel(p.status)}
                  </span>
                </div>

                <div className="text-2xl font-black text-slate-900">
                  {formatRupiah(p.amount)}
                </div>

                {p.status === 'lunas' ? (
                  <p className="text-xs text-slate-500">
                    Lunas Pada: <span className="font-semibold text-slate-800">{p.paymentDate}</span> ({p.paymentMethod})
                  </p>
                ) : (
                  <p className="text-xs text-amber-700 font-medium">
                    Jatuh Tempo Pembayaran: {p.dueDate}
                  </p>
                )}
              </div>

              <div className="pt-3 border-t border-slate-100 flex items-center justify-between">
                {p.status === 'belum_bayar' ? (
                  <button
                    onClick={() => setSelectedPay(p)}
                    className="w-full py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs shadow-md transition-colors"
                  >
                    Bayar SPP Sekarang (Virtual Account / QRIS)
                  </button>
                ) : (
                  <button 
                    onClick={() => alert(`Mengunduh Kuitansi Resmi KABIN Pay - SPP ${p.month}.pdf`)}
                    className="w-full py-2 bg-slate-100 hover:bg-slate-200 text-slate-800 font-bold rounded-xl text-xs flex items-center justify-center gap-2"
                  >
                    <Download className="w-3.5 h-3.5" />
                    <span>Cetak Kuitansi Pembayaran (PDF)</span>
                  </button>
                )}
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Pay Modal */}
      {selectedPay && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl max-w-md w-full p-6 space-y-5 shadow-2xl">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3">
              <h3 className="font-bold text-slate-900 text-base">
                KABIN Pay Virtual Account
              </h3>
              <button 
                onClick={() => setSelectedPay(null)}
                className="text-slate-400 hover:text-slate-600 font-bold text-sm"
              >
                ✕
              </button>
            </div>

            <div className="p-4 bg-slate-50 rounded-2xl border border-slate-200/80 space-y-3">
              <div className="flex justify-between text-xs text-slate-600">
                <span>Tagihan Bulan:</span>
                <span className="font-bold text-slate-900">{selectedPay.month}</span>
              </div>
              <div className="flex justify-between text-xs text-slate-600">
                <span>Total Nominal:</span>
                <span className="font-extrabold text-indigo-600 text-sm">{formatRupiah(selectedPay.amount)}</span>
              </div>

              <div className="pt-2 border-t border-slate-200/60">
                <span className="text-[10px] font-bold text-slate-400 uppercase">Nomor Virtual Account Mandiri / BCA:</span>
                <div className="flex items-center justify-between bg-white p-2.5 rounded-xl border border-slate-200 mt-1">
                  <span className="font-mono font-bold text-slate-900 text-sm tracking-wider">
                    {selectedPay.vaNumber}
                  </span>
                  <button
                    onClick={() => handleCopyVa(selectedPay.vaNumber || '')}
                    className="p-1.5 text-indigo-600 hover:bg-indigo-50 rounded-lg text-xs font-bold flex items-center gap-1"
                  >
                    <Copy className="w-3.5 h-3.5" />
                    <span>{copiedVa ? 'Tersalin' : 'Salin'}</span>
                  </button>
                </div>
              </div>
            </div>

            <div className="text-center p-4 bg-emerald-50 rounded-2xl border border-emerald-100 space-y-2">
              <QrCode className="w-12 h-12 text-emerald-600 mx-auto" />
              <p className="text-xs font-bold text-emerald-900">Scan QRIS KABIN Pay</p>
              <p className="text-[11px] text-emerald-700">Mendukung Gopay, OVO, ShopeePay, BCA Mobile, Livin</p>
            </div>

            <div className="flex gap-2 pt-2">
              <button
                type="button"
                onClick={() => setSelectedPay(null)}
                className="w-1/2 py-2.5 rounded-xl bg-slate-100 text-slate-700 text-xs font-bold"
              >
                Tutup
              </button>
              <button
                onClick={handleConfirmPayment}
                className="w-1/2 py-2.5 rounded-xl bg-emerald-600 text-white text-xs font-bold hover:bg-emerald-700 shadow-md"
              >
                Konfirmasi Simulasi Bayar
              </button>
            </div>
          </div>
        </div>
      )}

    </div>
  );
};
