import React, { useState } from 'react';
import { 
  Users, 
  BookOpen, 
  CheckSquare, 
  Sparkles, 
  FilePlus, 
  QrCode, 
  ArrowRight,
  GraduationCap,
  CalendarCheck,
  CheckCircle2,
  Clock
} from 'lucide-react';
import { UserProfile } from '../types';
import { MOCK_GRADES, MOCK_ASSIGNMENTS } from '../data/mockData';

interface DashboardGuruProps {
  profile: UserProfile;
  onNavigate: (tab: string) => void;
  onOpenAiModal: () => void;
}

export const DashboardGuru: React.FC<DashboardGuruProps> = ({
  profile,
  onNavigate,
  onOpenAiModal,
}) => {
  const [showQrModal, setShowQrModal] = useState(false);
  const [scannedMessage, setScannedMessage] = useState<string | null>(null);

  const pendingGradingCount = MOCK_ASSIGNMENTS.filter(a => a.status === 'sudah_dikirim').length;

  const handleSimulateScan = () => {
    setScannedMessage('Presensi Berhasil! Siswa: Dimas Anggara (XII MIPA 1) - Status: Hadir Tepat Waktu (06.45 WIB)');
    setTimeout(() => {
      setScannedMessage(null);
      setShowQrModal(false);
    }, 2500);
  };

  return (
    <div className="space-y-6">
      
      {/* Teacher Banner */}
      <div className="relative overflow-hidden rounded-3xl bg-gradient-to-r from-emerald-900 via-teal-800 to-slate-900 text-white p-6 sm:p-8 shadow-xl shadow-teal-950/10">
        <div className="relative z-10 flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
          <div className="space-y-2 max-w-xl">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-white/10 backdrop-blur-md border border-white/10 text-xs font-semibold text-emerald-200">
              <BookOpen className="w-3.5 h-3.5 text-emerald-300" />
              <span>Portal Guru & Pengajar KABIN</span>
            </div>
            <h2 className="text-2xl sm:text-3xl font-extrabold tracking-tight">
              Selamat Mengajar, {profile.name}! 🍎
            </h2>
            <p className="text-emerald-100 text-sm leading-relaxed">
              {profile.kelasOrMapel}. Ada <span className="font-bold text-amber-300">{pendingGradingCount} berkas tugas siswa</span> yang siap diperiksa hari ini.
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-3">
            <button
              onClick={() => setShowQrModal(true)}
              className="px-4 py-2.5 rounded-xl bg-gradient-to-r from-emerald-400 to-teal-400 text-slate-950 text-sm font-bold shadow-lg flex items-center gap-2 transition-all hover:scale-[1.02]"
            >
              <QrCode className="w-4 h-4" />
              <span>Scan QR Presensi Kelas</span>
            </button>
            <button
              onClick={onOpenAiModal}
              className="px-4 py-2.5 rounded-xl bg-white/10 hover:bg-white/20 text-white border border-white/15 text-sm font-semibold flex items-center gap-2"
            >
              <Sparkles className="w-4 h-4 text-amber-300" />
              <span>Buat RPP / Quiz AI</span>
            </button>
          </div>
        </div>
      </div>

      {/* Metrics Row */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        
        <div className="bg-white p-5 rounded-2xl border border-slate-200/80 shadow-xs">
          <div className="flex items-center justify-between">
            <span className="text-xs font-medium text-slate-500 uppercase tracking-wider">Siswa Binaan Wali</span>
            <div className="w-9 h-9 rounded-xl bg-emerald-50 text-emerald-600 flex items-center justify-center">
              <Users className="w-5 h-5" />
            </div>
          </div>
          <div className="mt-3 flex items-baseline gap-2">
            <span className="text-3xl font-extrabold text-slate-900">36</span>
            <span className="text-xs font-medium text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded-full">
              XII MIPA 1
            </span>
          </div>
          <p className="text-xs text-slate-500 mt-1">100% Kehadiran Kelas Hari Ini</p>
        </div>

        <div className="bg-white p-5 rounded-2xl border border-slate-200/80 shadow-xs">
          <div className="flex items-center justify-between">
            <span className="text-xs font-medium text-slate-500 uppercase tracking-wider">Perlu Dinilai</span>
            <div className="w-9 h-9 rounded-xl bg-amber-50 text-amber-600 flex items-center justify-center">
              <CheckSquare className="w-5 h-5" />
            </div>
          </div>
          <div className="mt-3 flex items-baseline gap-2">
            <span className="text-3xl font-extrabold text-slate-900">{pendingGradingCount}</span>
            <span className="text-xs font-medium text-amber-700 bg-amber-50 px-2 py-0.5 rounded-full">
              Tugas Praktikum
            </span>
          </div>
          <p className="text-xs text-slate-500 mt-1">Fisika & Matematika Peminatan</p>
        </div>

        <div className="bg-white p-5 rounded-2xl border border-slate-200/80 shadow-xs">
          <div className="flex items-center justify-between">
            <span className="text-xs font-medium text-slate-500 uppercase tracking-wider">Jadwal Mengajar Hari Ini</span>
            <div className="w-9 h-9 rounded-xl bg-blue-50 text-blue-600 flex items-center justify-center">
              <CalendarCheck className="w-5 h-5" />
            </div>
          </div>
          <div className="mt-3 flex items-baseline gap-2">
            <span className="text-3xl font-extrabold text-slate-900">4 JP</span>
            <span className="text-xs font-medium text-blue-700 bg-blue-50 px-2 py-0.5 rounded-full">
              2 Sesi Kelas
            </span>
          </div>
          <p className="text-xs text-slate-500 mt-1">Sesi Lanjutan Pukul 10.15 WIB</p>
        </div>

        <div className="bg-white p-5 rounded-2xl border border-slate-200/80 shadow-xs">
          <div className="flex items-center justify-between">
            <span className="text-xs font-medium text-slate-500 uppercase tracking-wider">Rata-Rata Kelas Wali</span>
            <div className="w-9 h-9 rounded-xl bg-purple-50 text-purple-600 flex items-center justify-center">
              <GraduationCap className="w-5 h-5" />
            </div>
          </div>
          <div className="mt-3 flex items-baseline gap-2">
            <span className="text-3xl font-extrabold text-slate-900">88.4</span>
            <span className="text-xs font-bold text-purple-700 bg-purple-50 px-2 py-0.5 rounded-full">
              Unggul
            </span>
          </div>
          <p className="text-xs text-slate-500 mt-1">Kelas Tertinggi Paralel MIPA</p>
        </div>

      </div>

      {/* Class List & Quick Grading */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* Class Roster Quick Overview */}
        <div className="lg:col-span-2 bg-white rounded-2xl border border-slate-200/80 p-6 shadow-xs">
          <div className="flex items-center justify-between mb-5">
            <div>
              <h3 className="text-base font-bold text-slate-900">
                Daftar Kelas Binaan & Mengajar
              </h3>
              <p className="text-xs text-slate-500 mt-0.5">Kelola Nilai, Jurnal Mengajar, dan Presensi Siswa</p>
            </div>
            <button 
              onClick={() => onNavigate('nilai')}
              className="text-xs font-bold text-indigo-600 hover:text-indigo-800 flex items-center gap-1"
            >
              <span>Input Nilai Rapor</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>

          <div className="space-y-3">
            {[
              { kelas: 'XII MIPA 1', mapel: 'Matematika Peminatan', siswaCount: 36, status: 'Wali Kelas', time: '07.00 - 08.30 WIB' },
              { kelas: 'XII MIPA 2', mapel: 'Matematika Peminatan', siswaCount: 35, status: 'Pengajar', time: '10.15 - 11.45 WIB' },
              { kelas: 'XI MIPA 3', mapel: 'Matematika Wajib', siswaCount: 36, status: 'Pengajar', time: 'Besok, 08.30 WIB' },
            ].map((cls, idx) => (
              <div key={idx} className="p-4 rounded-xl border border-slate-200/80 bg-slate-50/50 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                <div>
                  <div className="flex items-center gap-2">
                    <h4 className="font-bold text-slate-900 text-sm">{cls.kelas}</h4>
                    <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-800">
                      {cls.status}
                    </span>
                  </div>
                  <p className="text-xs text-slate-600 mt-1">{cls.mapel} • {cls.siswaCount} Siswa Terdaftar</p>
                </div>

                <div className="flex items-center gap-2">
                  <button 
                    onClick={() => setShowQrModal(true)}
                    className="px-3 py-1.5 rounded-lg bg-white border border-slate-300 text-slate-700 text-xs font-semibold hover:bg-slate-100"
                  >
                    Presensi
                  </button>
                  <button 
                    onClick={() => onNavigate('nilai')}
                    className="px-3 py-1.5 rounded-lg bg-indigo-600 text-white text-xs font-semibold hover:bg-indigo-700"
                  >
                    Input Nilai
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* AI Lesson Plan Generator Quick Box */}
        <div className="bg-gradient-to-br from-indigo-900 to-slate-900 text-white rounded-2xl p-6 flex flex-col justify-between shadow-md">
          <div className="space-y-3">
            <div className="w-10 h-10 rounded-xl bg-amber-400/20 border border-amber-400/30 text-amber-300 flex items-center justify-center">
              <Sparkles className="w-6 h-6" />
            </div>
            <h3 className="text-lg font-bold text-white">
              KABIN AI Teacher Assistant
            </h3>
            <p className="text-xs text-slate-300 leading-relaxed">
              Hemat waktu hingga 70%! Generate RPP Kurikulum Merdeka, Kisi-kisi Soal CBT, atau Catatan Rapor Karakter siswa secara otomatis dengan Gemini AI.
            </p>
          </div>

          <button
            onClick={onOpenAiModal}
            className="mt-6 w-full py-2.5 rounded-xl bg-amber-400 hover:bg-amber-500 text-slate-950 font-bold text-xs flex items-center justify-center gap-2 shadow-lg shadow-amber-400/20 transition-all"
          >
            <span>Buka Generator RPP AI</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>

      </div>

      {/* QR Scanner Modal Simulation */}
      {showQrModal && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl max-w-md w-full p-6 space-y-5 shadow-2xl animate-in zoom-in-95">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3">
              <h3 className="font-bold text-slate-900 text-base flex items-center gap-2">
                <QrCode className="w-5 h-5 text-emerald-600" />
                Scanner QR Presensi KABIN
              </h3>
              <button 
                onClick={() => setShowQrModal(false)}
                className="text-slate-400 hover:text-slate-600 font-bold text-sm"
              >
                ✕
              </button>
            </div>

            <div className="bg-slate-950 rounded-2xl p-6 text-center text-white space-y-4">
              <div className="w-48 h-48 mx-auto border-2 border-dashed border-emerald-400 rounded-xl flex items-center justify-center bg-emerald-950/30 relative overflow-hidden">
                <div className="absolute inset-x-0 top-0 h-1 bg-emerald-400 animate-bounce" />
                <QrCode className="w-24 h-24 text-emerald-400 opacity-60" />
              </div>
              <p className="text-xs text-slate-300">
                Arahkan Kartu Pelajar Digital / HP Siswa ke Kamera
              </p>
            </div>

            {scannedMessage ? (
              <div className="p-3 bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs font-semibold rounded-xl flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                <span>{scannedMessage}</span>
              </div>
            ) : (
              <button
                onClick={handleSimulateScan}
                className="w-full py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs"
              >
                Simulasi Scan Siswa (Dimas Anggara)
              </button>
            )}
          </div>
        </div>
      )}

    </div>
  );
};
