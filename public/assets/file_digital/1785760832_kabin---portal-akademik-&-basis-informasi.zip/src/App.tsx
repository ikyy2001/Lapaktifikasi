import React, { useState } from 'react';
import { UserRole } from './types';
import { MOCK_PROFILES } from './data/mockData';

// Component imports
import { Sidebar } from './components/Sidebar';
import { Header } from './components/Header';
import { DashboardSiswa } from './components/DashboardSiswa';
import { DashboardGuru } from './components/DashboardGuru';
import { DashboardOrangTua } from './components/DashboardOrangTua';
import { DashboardAdmin } from './components/DashboardAdmin';
import { JadwalSection } from './components/JadwalSection';
import { NilaiRaporSection } from './components/NilaiRaporSection';
import { PresensiSection } from './components/PresensiSection';
import { TugasUjianSection } from './components/TugasUjianSection';
import { PengumumanSection } from './components/PengumumanSection';
import { KeuanganSection } from './components/KeuanganSection';
import { AiAsistenModal } from './components/AiAsistenModal';
import { NotificationDrawer } from './components/NotificationDrawer';

export default function App() {
  const [activeTab, setActiveTab] = useState<string>('dashboard');
  const [currentRole, setCurrentRole] = useState<UserRole>('siswa');
  const [isMobileOpen, setIsMobileOpen] = useState<boolean>(false);
  const [isNotificationsOpen, setIsNotificationsOpen] = useState<boolean>(false);
  const [isAiModalOpen, setIsAiModalOpen] = useState<boolean>(false);

  const currentProfile = MOCK_PROFILES[currentRole];

  // Render main section based on active tab
  const renderContent = () => {
    if (activeTab === 'dashboard') {
      switch (currentRole) {
        case 'siswa':
          return (
            <DashboardSiswa
              profile={currentProfile}
              onNavigate={(tab) => setActiveTab(tab)}
              onOpenAiModal={() => setIsAiModalOpen(true)}
            />
          );
        case 'guru':
          return (
            <DashboardGuru
              profile={currentProfile}
              onNavigate={(tab) => setActiveTab(tab)}
              onOpenAiModal={() => setIsAiModalOpen(true)}
            />
          );
        case 'orang_tua':
          return (
            <DashboardOrangTua
              profile={currentProfile}
              onNavigate={(tab) => setActiveTab(tab)}
            />
          );
        case 'admin':
          return (
            <DashboardAdmin
              profile={currentProfile}
              onNavigate={(tab) => setActiveTab(tab)}
            />
          );
        default:
          return null;
      }
    }

    switch (activeTab) {
      case 'jadwal':
        return <JadwalSection />;
      case 'nilai':
        return <NilaiRaporSection userRole={currentRole} />;
      case 'presensi':
        return <PresensiSection />;
      case 'tugas':
        return <TugasUjianSection />;
      case 'pengumuman':
        return <PengumumanSection userRole={currentRole} />;
      case 'keuangan':
        return <KeuanganSection />;
      case 'ai-asisten':
        return (
          <div className="bg-white p-8 rounded-3xl border border-slate-200/80 text-center space-y-4 shadow-xs">
            <h2 className="text-xl font-extrabold text-slate-900">KABIN AI Teacher & Student Assistant</h2>
            <p className="text-xs text-slate-500 max-w-md mx-auto">
              Fitur AI terintegrasi dengan Google Gemini 2.5 Flash untuk membantu persiapan materi, pembuatan soal, dan bimbingan belajar.
            </p>
            <button
              onClick={() => setIsAiModalOpen(true)}
              className="px-6 py-3 rounded-2xl bg-indigo-600 text-white text-xs font-bold shadow-lg hover:bg-indigo-700 transition-colors"
            >
              Buka Modal KABIN AI Sekarang
            </button>
          </div>
        );
      default:
        return (
          <DashboardSiswa
            profile={currentProfile}
            onNavigate={(tab) => setActiveTab(tab)}
            onOpenAiModal={() => setIsAiModalOpen(true)}
          />
        );
    }
  };

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col lg:flex-row font-['Plus_Jakarta_Sans',sans-serif]">
      {/* Sidebar Navigation */}
      <Sidebar
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        currentRole={currentRole}
        isMobileOpen={isMobileOpen}
        setIsMobileOpen={setIsMobileOpen}
      />

      {/* Main Workspace Area */}
      <div className="flex-1 flex flex-col min-w-0">
        {/* Sticky Header */}
        <Header
          currentProfile={currentProfile}
          setCurrentRole={setCurrentRole}
          onOpenMobileMenu={() => setIsMobileOpen(true)}
          onOpenNotifications={() => setIsNotificationsOpen(true)}
          onOpenAiModal={() => setIsAiModalOpen(true)}
        />

        {/* Dynamic Main View */}
        <main className="flex-1 p-4 sm:p-6 lg:p-8 max-w-7xl w-full mx-auto">
          {renderContent()}
        </main>
      </div>

      {/* AI Assistant Modal */}
      <AiAsistenModal
        isOpen={isAiModalOpen}
        onClose={() => setIsAiModalOpen(false)}
        userRole={currentRole}
      />

      {/* Notifications Drawer */}
      <NotificationDrawer
        isOpen={isNotificationsOpen}
        onClose={() => setIsNotificationsOpen(false)}
      />
    </div>
  );
}
