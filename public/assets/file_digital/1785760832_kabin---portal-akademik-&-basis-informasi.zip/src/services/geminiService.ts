import { GoogleGenAI } from '@google/genai';

let aiInstance: GoogleGenAI | null = null;

const getAi = () => {
  if (!aiInstance) {
    const env = (import.meta as unknown as { env?: Record<string, string> }).env || {};
    const apiKey = env.VITE_GEMINI_API_KEY || process.env.GEMINI_API_KEY || '';
    if (apiKey) {
      aiInstance = new GoogleGenAI({ apiKey });
    }
  }
  return aiInstance;
};

export const askKabinAi = async (prompt: string, contextRole: string = 'siswa'): Promise<string> => {
  const ai = getAi();
  
  if (!ai) {
    // Return intelligent fallback responses based on topic
    return getFallbackAiResponse(prompt, contextRole);
  }

  try {
    const systemInstruction = `Anda adalah "KABIN AI Asisten", asisten kecerdasan buatan terpadu untuk KABIN (Kawasan Akademik & Basis Informasi). 
Anda melayani pengguna dengan peran: ${contextRole}.
Gaya bahasa: Sopan, inspiratif, suportif, berwawasan akademis Indonesia, dan akurat.
Jika pengguna meminta bantuan belajar, berikan penjelasan langkah demi langkah.
Jika guru meminta RPP / Modul Ajar / Soal, format dengan Markdown yang rapi.`;

    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: prompt,
      config: {
        systemInstruction,
        temperature: 0.7,
      },
    });

    return response.text || 'Maaf, KABIN AI sedang tidak dapat memberikan jawaban saat ini.';
  } catch (err) {
    console.warn('Gemini API call failed, falling back:', err);
    return getFallbackAiResponse(prompt, contextRole);
  }
};

function getFallbackAiResponse(prompt: string, role: string): string {
  const lower = prompt.toLowerCase();

  if (lower.includes('jadwal') || lower.includes('pelajaran')) {
    return `### 📅 Informasi Jadwal KABIN\nJadwal pelajaran Anda untuk hari ini dapat dilihat langsung pada tab **Jadwal & Kalender**. Kelas XII MIPA 1 hari ini meliputi Matematika Peminatan, Fisika, dan Bahasa Indonesia. Pastikan datang 15 menit sebelum bel masuk pukul 07.00 WIB!`;
  }
  
  if (lower.includes('rpp') || lower.includes('soal') || lower.includes('modul')) {
    return `### 📝 Draf RPP & Modul Ajar Otomatis\n**Mata Pelajaran:** Matematika Peminatan (Kalkulus & Integral)\n**Kelas:** XII MIPA\n\n1. **Tujuan Pembelajaran:** Siswa mampu menentukan nilai integral tentu fungsi trigonometri dengan tepat.\n2. **Kegiatan Inti:** Diskusi kelompok berbasis masalah (PBL) dan latihan CBT interaktif.\n3. **Asesmen:** Quis singkat 5 soal & Refleksi Mandiri di Portal KABIN.`;
  }

  if (lower.includes('nilai') || lower.includes('rapor') || lower.includes('spp')) {
    return `### 📊 Portal Akademik & Keuangan KABIN\nRata-rata nilai rapor Anda semester ini adalah **89.2 (Predikat A)**. Rincian selengkapnya serta status tagihan SPP bulanan dapat dipantau langsung melalui menu **Nilai & Rapor** dan **Keuangan SPP**.`;
  }

  return `### 🤖 KABIN AI Support (${role.toUpperCase()})\nHalo! Saya KABIN AI Asisten. Saya dapat membantu Anda:\n- Bimbingan materi pelajaran (Matematika, Fisika, Kimia, dll)\n- Penyusunan Draf RPP & Latihan Soal untuk Guru\n- Informasi Kegiatan, Nilai & Presensi Sekolah\n\nSilakan ajukan pertanyaan atau topik spesifik yang ingin Anda pelajari!`;
}
