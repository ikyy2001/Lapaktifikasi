export const formatRupiah = (amount: number): string => {
  return new Intl.NumberFormat('id-ID', {
    style: 'currency',
    currency: 'IDR',
    maximumFractionDigits: 0,
  }).format(amount);
};

export const formatDateIndonesian = (dateString: string): string => {
  if (!dateString) return '-';
  try {
    const date = new Date(dateString);
    if (isNaN(date.getTime())) return dateString;
    return new Intl.DateTimeFormat('id-ID', {
      day: 'numeric',
      month: 'long',
      year: 'numeric',
    }).format(date);
  } catch {
    return dateString;
  }
};

export const getStatusBadgeClass = (status: string): string => {
  switch (status.toLowerCase()) {
    case 'hadir':
    case 'lunas':
    case 'dinilai':
    case 'selesai':
      return 'bg-emerald-100 text-emerald-800 border-emerald-200';
    case 'izin':
    case 'menunggu_verifikasi':
    case 'sudah_dikirim':
    case 'berlangsung':
      return 'bg-amber-100 text-amber-800 border-amber-200';
    case 'sakit':
      return 'bg-blue-100 text-blue-800 border-blue-200';
    case 'alpha':
    case 'belum_bayar':
    case 'belum_dikirim':
    case 'terlambat':
      return 'bg-rose-100 text-rose-800 border-rose-200';
    default:
      return 'bg-slate-100 text-slate-800 border-slate-200';
  }
};

export const getStatusLabel = (status: string): string => {
  switch (status) {
    case 'belum_dikirim':
      return 'Belum Mengirim';
    case 'sudah_dikirim':
      return 'Sudah Mengirim';
    case 'dinilai':
      return 'Telah Dinilai';
    case 'lunas':
      return 'Lunas';
    case 'belum_bayar':
      return 'Belum Dibayar';
    case 'menunggu_verifikasi':
      return 'Proses Verifikasi';
    default:
      return status;
  }
};
