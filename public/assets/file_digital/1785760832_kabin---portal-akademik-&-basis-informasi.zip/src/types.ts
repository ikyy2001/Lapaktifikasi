export type UserRole = 'siswa' | 'guru' | 'orang_tua' | 'admin';

export interface UserProfile {
  id: string;
  name: string;
  role: UserRole;
  avatar: string;
  nipNis: string;
  kelasOrMapel: string;
  email: string;
  phone: string;
  schoolName: string;
  academicYear: string;
  semester: string;
}

export interface ScheduleItem {
  id: string;
  subject: string;
  teacher: string;
  time: string;
  day: 'Senin' | 'Selasa' | 'Rabu' | 'Kamis' | 'Jumat' | 'Sabtu';
  room: string;
  color: string;
  status?: 'selesai' | 'berlangsung' | 'belum';
}

export interface GradeItem {
  subject: string;
  code: string;
  teacher: string;
  kkm: number;
  tugas: number;
  uts: number;
  uas: number;
  finalGrade: number;
  letterGrade: 'A' | 'B' | 'C' | 'D';
  predikat: string;
  catatan: string;
}

export interface AttendanceRecord {
  id: string;
  date: string;
  day: string;
  timeIn: string;
  timeOut: string;
  status: 'Hadir' | 'Izin' | 'Sakit' | 'Alpha' | 'Terlambat';
  notes?: string;
}

export interface Assignment {
  id: string;
  title: string;
  subject: string;
  teacher: string;
  deadline: string;
  status: 'belum_dikirim' | 'sudah_dikirim' | 'dinilai';
  score?: number;
  description: string;
  attachmentUrl?: string;
}

export interface Announcement {
  id: string;
  title: string;
  category: 'Akademik' | 'Kegiatan' | 'Keuangan' | 'Penting';
  date: string;
  author: string;
  authorRole: string;
  authorAvatar: string;
  summary: string;
  content: string;
  pinned?: boolean;
  image?: string;
  readCount: number;
}

export interface PaymentItem {
  id: string;
  month: string;
  amount: number;
  dueDate: string;
  status: 'lunas' | 'belum_bayar' | 'menunggu_verifikasi';
  paymentDate?: string;
  paymentMethod?: string;
  vaNumber?: string;
}

export interface ChatMessage {
  id: string;
  sender: 'user' | 'ai' | 'system';
  text: string;
  timestamp: string;
  sources?: string[];
}
